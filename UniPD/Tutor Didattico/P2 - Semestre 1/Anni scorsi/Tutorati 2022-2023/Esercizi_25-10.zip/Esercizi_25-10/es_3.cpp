/*Definire una classe 'Persona' i cui oggetti rappresentano anagraficamente un
personaggio storico caratterizzato da nome, anno dI nascita e anno di morte.
Includere opportuni costruttori, metodi di accesso ai campi e l'overloading
dell'operatore di output come funzione esterna. Separare interfaccia ed
implementazione della classe.
Si definisca inoltre un esempio al metodo 'main() che usa tutti i metodi della
classe e l'operatore di output. */

