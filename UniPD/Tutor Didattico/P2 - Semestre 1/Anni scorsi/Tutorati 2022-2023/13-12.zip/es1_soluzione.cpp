/* Definire un template di classe stack<T, num> i cui oggetti rappresentano uno stack di valori di un generico, tipo I con al massimo num elementi.
Si ricorda che lo stack implementa la politica di inserimento/rimozione LIFO: Last In First Out. Lo stack si dice pieno quando memorizza num elementi.
Il template stack<T, num> deve soddisfare i seguenti vincoli e rendere disponibili le seguenti funzionalità:
    1. stack<T, num> non può usare i contenitori STL come campi dati (inclusi puntatori e riferimenti a contenitori STL).
    2. Il template stack<T, num> ha come tipo T default char e come valore num default 100.
    3. Un costruttore di default che costruisce lo stack vuoto.
    4. Un costruttore stack (t, k) che costruisce uno stack di k elementi che memorizzano il valore t; se k > num allora lo stack sarà di num
        elementi, se k < 0 allora lo stack sarà vuoto.
    5. Metodi bool isEmpty () e bool isFu11 () che testano se lo stack è vuoto o pieno.
    6. Metodo unsigned int size () che ritorna il numero di elementi memorizzati dallo stack.
    7. Gestione della memoria senza condivisione.
    8. Operatore esplicito di conversione ad int che ritorna la dimensione dello stack.
    9. Metodo bool push (const T&): in una chiamata s.push (t), inserisce al top dello stack s un nuovo elemento che memorizza il valore t se
        ciò non provoca il superamento del limite num, altrimenti lascia lo stack s invariato. Ritorna true se l'inserimento è avvenuto, false
        altrimenti.
    10. Metodo void pop (): in una chiamata s .pop () rimuove l'elemento al top dello stack s non vuoto; se s è vuoto lo lascia inalterato.
    11. Metodo T top():s.top() ritorna una copia dell'elemento al top dello stack s non vuoto; se s è vuoto, allora s.top() provoca undefined
        behaviour (da definirsi opportunamente).
    12. Metodo I bottom (): s.bottom () ritorna una copia dell'elemento al bottom dello stack s non vuoto; se s è vuoto,
        allora s. bottom ( ) provoca undefined behaviour (da definirsi opportunamente).
    13. Metodo bool search (const T&): in una chiamata s. search (t) ritorna true se il valore t occorre nello stack s,
        altrimenti ritorna false.
    14. Metodo void flush () che svuota lo stack di invocazione.
    15. Overloading dell'operatore di somma tra stack: s1 + s2 deve ritornare un nuovo stack ottenuto impilando s2 sopra s1 (il bottom di s2 è
        quindi sopra il top s1), sino all'eventuale raggiungimento del massimo num di elementi.
    16. Overloading dell'operatore di uguaglianza.
    17. Overloading dell'operatore di output.
    */




template<class T, int num>
template <class T = char, int num = 100>
class stack {
    private:
        T* elem;
        int cont;
    public:
        stack() : elem(new T(num), n(0)) {}
        stack(const T&, int k) : elem(new T(num)) {
            if(k>num)
                k =num;
            else if (k<0)
                k = 0;
            cont = k;
            for (int i=0; i<cont; ++i) {
                elem[i] = t;
            }
        }
}

   // Usare una lista o un array dimanmico, allocando num e tenendo conto quant'è l'oggetto corrente

   //PUNTO 11 classe per errori TIP per esame: meglio definire la classe senza contenuto per ottimizzare
   class EmptyStack {
   };

   template<class T, int num>
    stack<T, num> operator+(const stack<T, num>& s1, const stack<T, num>& s2);
   template <class T = char, int num = 100> // PUNTO 1/2
    
    class stack {
    private:
        T* elem;
        int const;
    public:
        stack() : elem(new T(num)), cont(0) {} // PUNTO 3
        stack(const T&, int k) : elem(new T[num]) { // PUNTO 4 con i dovuti controlli
            if(k>num)
                k = num;
            else if (k<0)
                k = 0;
            cont = k;
            for (int i = 0; i < cont; ++i) {
                elem[i] =t;
            }
        }
        bool isEmpty() const { // PUNTO 5 si verifica che cont=0
            return cont == 0;
        }

        bool isFull() const {
            return cont == num;
        }

        unsigned int size() const { // PUNTO 6
            return cont;
        }

        stack(const& other) : elem(new T[num]), cont(other.cont) { // PUNTO 7 ridefinisco costruttore di copia
            for (int i = 0; i < cont; ++i) {
                elem[i] = other.elem[i];
            }
        }
        stack& operator=(const stack& other) {
            if(this != &other) {
                cont = other.cont;
                for (int i = 0; i < cont; ++i) {
                elem[i] = other.elem[i];
            }
        }
        return *this;
    }
    virtual ~stack() {
        delete[] elem;
    }

    operator int() const { // PUNTO 8 definiamo operatore di conversione
        return cont;
    }

    bool push(const T& t) { // PUNTO 9
        if(isFull) {
            return false;
        }
        elem[cont] = t;
        cont++;
        return true;
    }

    void pop() { // PUNTO 10
        if(!isEmpty()) {
            cont--;
            elem[cont] = T();
        }
    }
    T top() {// PUNTO 11 ritorna il primo elemento dello stack
        if(isEmpty()) {
            throw EmptyStack();
        }
        return elem[cont-1];
    }

    T bottom() { // PUNTO 12 ritorna l'ultimo elemento dello stack
        if(isEmpty()) {
            throw EmptyStack();
        }
        return elem[0];
    }

    void flush() { // PUNTO 14
        // for (int i = 0; i < cont; ++i) {
        //     elem[i] = T();
        // } soluzione 1
        cont = 0;
        delete[] elem;
        elem = new T[num];
    }

    friend stack<T, num> operator+(const stack<T, num>&s1, const stack<T, num>& s2);

    bool operator==(const stack& other) {// PUNTO 16 la miglior soluzione e' avere uno stack con stesso numero di elementi e di stessa dimensione
        if(other.cont != cont) return false;
        for (int i = 0; i < cont; ++i) {
            if (elem[i] != other.elem[i]) {
                return false;
            }
        }
        return true;
    }
};
// PUNTO 15 l'overloading si puo' fare sia all'interno che all'esterno, piu' comodo all'esterno
    template<class T, int num>
    stack<T, num> operator+(const stack<T, num>& s1, const stack<T, num>& s2) {
        stack<T, num> s3 = stack<T, num> (s1);
        // for(int i = s3.size(), j = 0; i < num && j < s2.size(); i++, j++) {
        //     s3.elem[i] = s2.elem[j];
        //     s3.cont;
        // }
        for(int = 0; i < s2.size(); ++i) {
            if(!s3.push(s2.elem[i])) {
                break;
            }
        }
        return s3;
    };
