class C {
 public:
   int a[2];
   C(int x=0,int y=1) {
      a[0]=x; a[1]=y; cout << "C(" << a[0] << "," << a[1] << ") ";
   }
};
 class D {
 private:
   C c1;
   C *c2;
   C& cr;
 public:
   D() : c2(&c1), cr(c1) { cout << "D() ";}
   D(const D& d) : cr(c1) { cout << "Dc ";}
    ̃D() { cout << " ̃D ";}
};
 class E {
 public:
   static C cs;
 };
C E::cs;
 int main() {
   C c; cout << "UNO" << endl; // C(0,1) C(0,1) -> a r.22 inizializza un elemento statico, richiamando il costruttore di default, poi creo una c 
   // con parametri di default, inzializza tutti i campi di tipo c
   C x(c); cout << x.a[0] << " " << x.a[1] << " DUE" << endl; // 0 1 DUE -> il costruttore di copia non è ridefinito, quindi non andrà a stampare nulla, 
   // poi nel cout stamperà 0 e 1
   D d=D(); cout << "TRE" << endl; // C(0,1) D C(0,1) Dc ~D -> la creazione di un elemento d comporta la creazione di un c (c1), quindi stamperà C(0,1)
   // poi nel operatore = viene richiamato il costruttore di copia di D che è definito, dove chiamerà il costruttore per c1, stampando C(0,1)
   // inoltre ci sara' la distruzione del temporaneo D, quindi ~D
   E e; cout << "QUATTRO" << endl; // -> Non stampa nulla
}
// Alla fine stamperà ~D
