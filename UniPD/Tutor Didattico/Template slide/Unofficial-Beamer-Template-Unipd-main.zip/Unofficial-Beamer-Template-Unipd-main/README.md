# Unofficial-Beamer-Template-Unipd
Unofficial Beamer theme LaTeX. Based on Warsaw theme, this is a cool presentation theme for project presentation at UniPD.
