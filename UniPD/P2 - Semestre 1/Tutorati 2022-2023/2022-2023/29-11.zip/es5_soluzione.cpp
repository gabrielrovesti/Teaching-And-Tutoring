#include <iostream>

class A{
private:
    int z;
public:
    ~A() { std::cout << "~A ";}
    };

class B{
public:
    A* p;
    A a;
    ~B() { std::cout << "~B ";}
};

class C{
public:
    static B s;
    int k;
    A a;
    ~C() { std::cout << "~C ";}
};

B C::s = B();

int main(){
    C c1,c2;
} /* ~C ~A ~C ~A ~B ~A -> Nella creazione dei due oggetti, chiamo costruttore default di C, costruendo un ogetto di tipo A che conterra' un int z
nella r.25 viene creato l'elemento tmep., assegnato al valore statico per poi essere eliminato subito dopo, quindi ~B e ~A;

dopodichè avviene la distruzione in ordine inverso quindi prima c2 e stampa ~C e ~A;

stessa cosa per c1 ~C ~A;

poi si passa al valore statico creato (r.25), che ha al suo interno due campi A (uno puntatore) quindi ~B e ~A

le distruzioni vengono fatte nel clean-up finale

*/