/* Il programma contiene le quattro dichiarazioni di amicizia (A), (B), (C), (D). Barrare
con una croce nel riquadro sottostante le dichiarazioni di amicizia che sono necessarie per la corretta
compilazione del programma (con gli opportuni #include e using): */

class N;
class S {
friend ostream& operator<<(ostream&, const S&); /* (A) SERVE -> Quando definiamo questo operatore abbiamo bisogno di un elemento della
classe S, e passarlo con dichiarazione per amicizia e' l'unico modo, cosi da poter accedere al campo Z
*/
friend void stampa(N*); // (B) NON SERVE -> Non accede a nessun campo privato
private:
string z;
public:
S(string x = ""): z(x) {}
};
ostream& operator<<(ostream& os, const S& x) {return os << x.z;}
class N {
friend class C; /* (C) SERVE -> Se guardiamo il costruttore di C, ad x assegna un valore di defualt chiamando il costruttore di N,
che a sua volta viene definito come privato, dovendo dichiarare l'amicizia per poterne fruire; stessa cosa per il metodo F
*/
friend void stampa(N*); /* (D) SERVE -> Se guardiamo la funzione stampa, accede a p->s, ed il campo s di questo elemento N e' privato,
quindi tale espressione non puo' essere valutata senza amicizia
*/
public:
N* next;
private:
S s;
N(S t, N* p): s(t), next(p) {}
};
class C {
public:
N* punt;
C( N* x = new N(string("ROSSO"),0) ) : punt(x) {}
void G() {if(punt) punt = punt->next;}
void F(string s1, string s2 = "BLU") {
punt = new N(s1,punt); punt = new N(s2,punt);
}
};
void Fun(C* p1, C* p2) { if(p1 != p2) {*p1 = *p2; p1->G();} }
void stampa(N* p) { if(p) {cout << p->s << ’ ’; stampa(p->next);} }
main(){
C* p = new C; p->F("VERDE");
C* q = new C((p->punt)->next); q->F("BIANCO","NERO");
stampa(p->punt); cout << "**1 " << endl;
stampa(q->punt); cout << "**2 " << endl;
C* t = new C(p->punt); Fun(p,q);
stampa(p->punt); cout << "**3 " << endl;
stampa(q->punt); cout << "**4 " << endl;
Fun(q,t);
stampa(p->punt); cout << "**5 " << endl;
stampa(q->punt); cout << "**6 " << endl;
q->F("GIALLO"); p->F("GIALLO");
stampa(p->punt); cout << "**7 " << endl;
stampa(q->punt); cout << "**8 " << endl;
}


