#include <iostream>

class A{
private:
    int z;
public:
    ~A() { std::cout << "~A ";}
    };

class B{
public:
    A* p;
    A a;
    ~B() { std::cout << "~B ";}
};

class C{
public:
    static B s;
    int k;
    A a;
    ~C() { std::cout << "~C ";}
};

B C::s = B();

int main(){
    C c1,c2;
}