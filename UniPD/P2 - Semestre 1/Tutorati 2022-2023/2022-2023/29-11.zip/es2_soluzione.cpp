#include <iostream>
using namespace std;

// gerarchia 1
class B {
public:
    ~B() {cout << "~B()";}
};

class D: public B {
public:
    ~D() {cout << "~D()";}
};

// gerarchia 2
class B2 {
public:
    virtual ~B2() {cout << "~B2()" ;} // distruttore virtuale
};

class D2: public B2 {
public:
    ~D2() {cout <<"~D2()";}
};
int main(void) {
B* b = new D;
B2* b2 = new D2;
delete b; cout << endl; /* ~B() -> Dopo essere stati creati 2 puntatori, chiamo delete b*/
delete b2; cout << endl; /* ~D2() ~B2() -> Dato che il distruttore è virtuale, vado prima nel distruttore di D2, poi quello di B2*/
}
