#include "Orario.h"

//Chiamo il metodo dalla classe per il .cpp
// tipo di ritorno - classe::nome_metodo(parametri)
void Orario::inizializza(int secondi, int ore){};

int main(){};