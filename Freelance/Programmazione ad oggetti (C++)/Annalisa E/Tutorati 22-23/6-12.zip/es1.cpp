// Cosa stampa il programma?

class N;
class S {
friend ostream& operator<<(ostream&, const S&); // (A)
friend void stampa(N*); // (B)
private:
string z;
public:
S(string x = ""): z(x) {}
};
ostream& operator<<(ostream& os, const S& x) {return os << x.z;}
class N {
friend class C; // (C)
friend void stampa(N*); // (D)
public:
N* next;
private:
S s;
N(S t, N* p): s(t), next(p) {}
};
class C {
public:
N* punt;
C( N* x = new N(string("ROSSO"),0) ) : punt(x) {}
void G() {if(punt) punt = punt->next;}
void F(string s1, string s2 = "BLU") {
punt = new N(s1,punt); punt = new N(s2,punt);
}
};
void Fun(C* p1, C* p2) { if(p1 != p2) {*p1 = *p2; p1->G();} }
void stampa(N* p) { if(p) {cout << p->s << ’ ’; stampa(p->next);} }

main(){
C* p = new C; p->F("VERDE");
C* q = new C((p->punt)->next); q->F("BIANCO","NERO");
stampa(p->punt); cout << "**1 " << endl;
stampa(q->punt); cout << "**2 " << endl;
C* t = new C(p->punt); Fun(p,q);
stampa(p->punt); cout << "**3 " << endl;
stampa(q->punt); cout << "**4 " << endl;
Fun(q,t);
stampa(p->punt); cout << "**5 " << endl;
stampa(q->punt); cout << "**6 " << endl;
q->F("GIALLO"); p->F("GIALLO");
stampa(p->punt); cout << "**7 " << endl;
stampa(q->punt); cout << "**8 " << endl;
}


