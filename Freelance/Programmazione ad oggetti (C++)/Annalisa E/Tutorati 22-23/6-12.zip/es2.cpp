/* Definire una superclasse Auto i cui oggetti rappresentano generiche automobili e due sue sottoclassi Benzina e Diesel,
i cui oggetti rappresentano automobili alimentate rispettivamente a benzina e a diesel (ovviamente non esistono automobili non
alimentate e si assume che ogni auto è o a benzina o a diesel). Ci interesserà l'aspetto fiscale delle automobili, cioe Il calcolo
del bollo auto.
Queste classi devono soddisfare le seguenti specifiche:

    - Ogni automobile e caratterizzata dal numero di cavalli fiscali. La tassa per cavallo fiscale e unica per tutte le automobili
    (sia benzina che diesel) ed e fissata in 5 euro. La classe Auto fornisce un metodo tassa() che ritorna la tassa di bollo fiscale
    per l' automobile di invocazione

    - La classe Diesel è dotata (almeno) di un costruttore ad un parametro intero x che permette di
    creare un'auto diesel di x cavalli fiscali. Il calcolo del bollo fiscale per un'auto diesel viene fatto nel sequente modo:
    si moltiplica il numero di cavalli fiscali per la tassa per cavallo fiscale e si somma una addizionale fiscale unica per ogni a
    utomobile diesel fissata in 100. Un'auto benzina può soddisfare o meno la normativa europea Euro4. La classe Benzina è dotata di
    (almeno) un costruttore ad un parametro intero x e ad un parametro booleano b che permette di creare Un auto benzina di x cavalli
    fiscali che soddisfa Euro4 se b vale true altrimenti che non soddisfa Euro4.

    - Il calcolo del bollo fiscale per un'auto benzina viene fatto nel sequente modo: si moltiplica il numero di cavalli fiscali per
    la tassa per cavallo fiscale; se l'auto soddisfa Euro4 allora si detrae un bonus fiscale unico per ogni automobile benzina
    fissato in 50 euro. altrimenti non vi è alcuna detrazione

    - Si definisca inoltre una classe ACI i cui oggetti rappresentano delle filiali ACI addette all'incasso dei bolli auto.
    Ogni oggetto ACI è caratterizzato da un vector di puntatori ad auto, cioè un
    oggetto vector«Auto*», che rappresenta la lista delle automobili gestite dalla filiale ACI. La classe ACI fornisce un metodo
    aggiungiAuto (const Auto& a) che aggiunge l'auto a alla lista gestita dalla filiale di invocazione. Inoltre, la classe ACI
    fornisce un metodo incassaBolli() che ritorna la somma totale dei bolli che devono pagare tutte le auto gestite dalla filiale di
    invocazione.

Definire infine un esempio di main() in cui viene costruita una filiale ACI a cui vengono aggiunte quattro automobili in modo tale
che l'incasso dei bolli ammonti a 1600 euro */


class Auto {
private:
    const static unsigned double tassaCF;
    usinged int cavalliFiscali;
public:
    virtual double tassa() {}
    virtual ~Auto()=0;
}

class Diesel : public Auto {
    // costruttore 1 parametro, addizionale fiscale (static double), relativo calcolo
}

class Benzina : public Auto {
    // almeno costruttore, booleano di istanza per euro4, campo statico detrazione
}

class ACI {
    // uso polimorfismo di auto, clonazione da effettuare con il metodo e non con il costruttore
}

main {
    // calcoli richiesti
}