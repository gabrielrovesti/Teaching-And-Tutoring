#include <vector>
#include <iostream>

using namespace std;

class Auto {
private:
    int cavalliFiscali;
    static const double tassaCF;
public:
    Auto(int x = 0) : cavalliFiscali(x) {}
    virtual double tassa() const { return tassaCF * cavalliFiscali;};
    virtual ~Auto() {};
    virtual Auto* clone() const = 0;
};

const double Auto::tassaCF = 5.0; // PUNTO 1

class Diesel : public Auto {
private:
    static const double addizionale;
public:
    Diesel(int x) : Auto(x) {}
    virtual double tassa() const { return Auto::tassa() + addizionale;}; // PUNTO 2
    virtual Diesel* clone() const {
        return new Diesel(*this);
    }
};

const double Diesel:: addizionale = 100.0;

class Benzina : public Auto {
    static const double detrazione;
    bool euro4;
public:
    Benzina(int x, bool b) : Auto(x), euro4(b) {};
    virtual double tassa() const { return Auto::tassa() - (euro4 ? detrazione : 0);}; // PUNTO 3
    virtual Benzina* clone() const {
        return new Benzina(*this);
    }
};

const double Benzina::detrazione = 50.0;

class ACI {
private:
    vector<Auto*> v;
public:
    void aggiungiAuto(const Auto& a) {
    v.push_back(a.clone());
}

double incassaBolli() const {
    double tot = 0;
    for(auto it = v.begin(); it != v.end(); ++it) {
        tot += (*it)->tassa();
    }
    return tot;// PUNTO BONUS
    }
};

virtual ~ACI() {
    for(auto it = v.begin(); it != v.end(); ++it) {
        delete *it;
    }
}
int main (void) {
    ACI aci;
    Diesel d1(60), d2(60), d3(60), d4(60);
    aci.aggiungiAuto(d1);
    aci.aggiungiAuto(d2);
    aci.aggiungiAuto(d3);
    aci.aggiungiAuto(d4);

    cout << aci.incassaBolli();
}