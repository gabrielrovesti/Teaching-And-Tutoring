// Cosa stampa il programma?

class N;
class S {
    friend ostream& operator<<(ostream&, const S&); // (A)
    friend void stampa(N*); // (B)
    private:
    string z;
    public:
    S(string x = ""): z(x) {}
};
ostream& operator<<(ostream& os, const S& x) {return os << x.z;}

class N {
    friend class C; // (C)
    friend void stampa(N*); // (D)
    public:
    N* next;
    private:
    S s;
    N(S t, N* p): s(t), next(p) {}
};

class C {
    public:
    N* punt;
    C( N* x = new N(string("ROSSO"),0) ) : punt(x) {}
    void G() {if(punt) punt = punt->next;}
    void F(string s1, string s2 = "BLU") {
        punt = new N(s1,punt); punt = new N(s2,punt);
    }
};

void Fun(C* p1, C* p2) { if(p1 != p2) {*p1 = *p2; p1->G();} }
void stampa(N* p) { if(p) {cout << p->s << ’ ’; stampa(p->next);}
}

main(){
    C* p = new C; p->F("VERDE"); /* BLU VERDE ROSSO -> Creo una nuova C con costruttore con valore di default(r.27), poi richiama F() su P (r.29) che aggiunge 2 stringhe in testa alla lista, quindi ha solo ROSSO al suo interno; 
    con il primo inserimento mette VERDE in testa e successivamente BLU
    */
    C* q = new C((p->punt)->next); q->F("BIANCO","NERO"); /* NERO BIANCO VERDE ROSSO -> Richiamo costruttore di C, dove pero' passo un nodo esistente, che e' il secondo nodo della lista precedente, quindi puntera' alla lista VERDE ROSSO
    poi si richiama la funzione F, la differenza e' che non usera' BLU come parametro di default, ma NERO
    */
    stampa(p->punt); cout << "**1 " << endl;
    stampa(q->punt); cout << "**2 " << endl;
    C* t = new C(p->punt); Fun(p,q); /* BIANCO VERDE ROSSO -> Crea una nuova lista che punta i nodi di p, poi chiama fun() (r.34) che controlla la diversita' delle due liste; poi nel corpo assegna usando l'assegnazione implicita, copiando tutti i dati,
    quindi p punta a gli stessi nodi di q; poi richiama G()(r.28), che fa avanzare di uno il punt, p in questo caso, puntando cosi a BIANCO VERDE ROSSO, q invece rimane immutato, quindi stampera' NERO BIANCO VERDE ROSSO
    */
    stampa(p->punt); cout << "**3 " << endl; // BIANCO VERDE ROSSO
    stampa(q->punt); cout << "**4 " << endl; // NERO BIANCO VERDE ROSSO
    Fun(q,t); /* t punta alla stessa lista di p iniziale (t invariato dalle prime chiamate a funzione); nel corpo di Fun() assegnazione di t a q, quindi puntera' a VERDE ROSSO; p invece NON È STATO modificato*/
    stampa(p->punt); cout << "**5 " << endl; /* BIANCO VERDE ROSSO */
    stampa(q->punt); cout << "**6 " << endl; /* VERDE ROSSO */
    q->F("GIALLO"); p->F("GIALLO"); /* F() fa cio' che facevamo in r. 39/42, ovvero chiamato F(), poi crea un nodo con la stringa e aggiunge in testa, stessa cosa per s2, quindi in testa viene aggiunto GIALLO e poi BLU */
    stampa(p->punt); cout << "**7 " << endl; // BLU GIALLO BIANCO VERDE ROSSO
    stampa(q->punt); cout << "**8 " << endl; // BLU GIALLO VERDE ROSSO
}


