// Soluzione
A <= B - Falso
A <= C - Falso
A <= D - Falso
B <= A - Verp
B <= C - Falso
B <= D - Vero
C <= A - Vero
C <= B - Falso
C <= D - Possibile
D <= A - Vero
D <= B - Falso
D <= C - Possibile
