// Consegna che rispetta le specifiche di codice sotto = il codice che c'è sotto

// Creami la classe Car che ha come attributi/proprietà
// le porte e un'alimentazione
// Dota la classe di opportuni costruttori e dell'overloading del metodo toString()
public class Car extends Vehicle{       // extends = "sono la sottoclasse di... "

    // private = sono visibili solo all'interno della classe Car
    private byte porte; // information hiding = attributi privati
    private boolean alimentazione; // 0=Benzina, 1=Diesel

    // Getter = che si vedano all'esterno (dato che sono private)

    public int getPorte(){
        return porte;
    }

    public boolean getAlimentazione(){
        return alimentazione;
    }

    // Esempi dei vari tipi di costruttori

    // costruttore di default = inizializza tutto a nullo
    Car(){
        super();
        this.porte = 0;
        this.alimentazione = false;
    }
    // Utilizzo nel main(): Car macchina(); = valore vuoto/iniziale
    // overloading = stesso nome ma con diversi parametri
    Car(byte porte, boolean alimentazione){
        this.porte = porte;
        this.alimentazione = alimentazione;
    }
    // Utilizzo nel main(): Car macchina(5, false); // do io dei parametri

    Car(byte porte, boolean alimentazione, String marca, byte anno, int cilindrata){
        super(marca, anno, cilindrata);
        // super = uso costruttore superclasse per valorizzare i parametri che eredito
        // costruisco i parametri della superclasse
        this.porte = porte;
        this.alimentazione = alimentazione;
    }
    // Utilizzo nel main(): Car macchina(5, false, "Ferrari", 2019, 2000); // do io dei parametri


    public String toString(){
        // ritorna una stringa con le informazioni della classe

        return "Macchina con marca: " + getMarca() + ", con cilindrata: " + getCilindrata()
                + "con anno: " + getAnno()  + " con porte : " + getPorte()
                + ", alimentazione" + getAlimentazione() + "";
    }
}