// Creami la classe Motorcycle che ha come attributi/proprietà
// i tempi.
// Dota la classe di opportuni costruttori e dell'overloading del metodo toString()
public class Motorcycle extends Vehicle{    // extends = "sono la sottoclasse di... "
    private int tempi;

    // costruttore completo = ti può bastare solo questo
    Motorcycle(String marca, byte anno, int cilindrata, int tempi) {
        super(marca, anno, cilindrata);
        this.tempi=tempi;
    }

    //overloading ad un parametro
    Motorcycle(int tempi){
        this.tempi = tempi;
    }

    public int getTempi(){
        return tempi;
    }

    public String toString() {
        // ritorna una stringa con le informazioni della classe

        return "Moto con marca: " + getMarca() + ", con cilindrata: " + getCilindrata()
                + "con anno: " + getAnno() + " con tempi : " + getTempi();
    }
}
