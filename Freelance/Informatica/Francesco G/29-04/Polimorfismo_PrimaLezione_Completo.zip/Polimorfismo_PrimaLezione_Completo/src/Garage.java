/*
Si realizzi una applicazione java per la gestione di un garage secondo le specifiche:
il garage ha al max 15 posti ognuno dei quali è identificato da un num a partire da 0
e per motivi di capienza può ospitare solo auto moto e furgoni partendo dalla classe base veicolo a motore V;
la si estenda, realizzando anche le classi che modellano le entità furgone (F) auto (A) e moto (M).

Ridefinire il metodo toString in modo che ogni entità possa esternalizzare
in forma di stringa tutte le informazioni che la riguardano.

Si implementi una classe che modelli il garage sopradescritto
offrendo le seguenti operazioni di gestione:
1) immissione di un nuovo veicolo
2) estrazione dal garage del veicolo che occupa un determinato posto (ritornare l'istanza del veicolo stesso)
3) stampa della situazione corrente dei posti nel garage veicolo:
marca,anno,cilindrata;
auto:porte, alimentazione (diesel/benzina)
moto:tempi
furgone:capacità
*/

// Garage = classe che usa le varie classi prima definite

public class Garage {
        int[] posti = new int[15];  // numero max di posti = 15
        // vogliamo gestire i singoli veicoli per posizione = me lo fa capire (2)
        // e per questo viene scelto un array di interi

    // 1) immissione di un nuovo veicolo = usi l'oggetto di tipo Vehicle
    // e metti tutti i valori di veicolo (marca, anno, cilindrata)
    public void insertVehicle(Vehicle nVehicle, String marca, byte anno, int cilindrata){
        for(int i=0; i<15 ;i++){
            if(posti[i] == 0){  // se ci sono posti vuoti = array "libero" in una posizione
                nVehicle = new Vehicle(marca, anno, cilindrata);
                // inserimento veicolo nella posizione "i" del vettore
                // = inserisco i dati del veicolo -> marca, anno, cilindrata
            }
            else System.out.println("Non ci sono posti rimanenti!");
            // non ci sono posti vuoti = array pieno
        }
    }


    // 2) estrazione dal garage del veicolo che occupa un determinato posto
    public void returnVehicle(int posto){
        System.out.println(posti[posto]);
        // es. voglio il veicolo in posizione 2

        // [{"Ferrari", 2017, 0}][{"Maserati", 2020, 1}] = spiegazione visiva
    }

    // 3) stampa della situazione corrente dei posti nel garage veicolo

    public void print(){
        for(int i=0;i<=posti.length;i++){
            //se posti[i] contiene la classe Car allora stampa queste cose.
            System.out.println("Veicolo: "  + posti[i]);
        }
    }

}

    /*
            Gerarchia (con Garage che è classe esterna dato che usa gli oggetti)

                Vehicle                     Garage
            /           \
         Car            Motorcycle


     */