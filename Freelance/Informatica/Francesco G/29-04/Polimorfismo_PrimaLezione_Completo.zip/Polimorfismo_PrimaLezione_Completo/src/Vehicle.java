public class Vehicle {
    // attributi = proprietà
    private String marca;
    private byte anno;
    private int cilindrata;

    public String getMarca(){
        return marca;
    }

    public byte getAnno(){
        return anno;
    }

    public int getCilindrata(){
        return cilindrata;
    }

    Vehicle(){
        this.marca = null;
        this.anno = 0;
        this.cilindrata = 0;
    }

    Vehicle(String marca, byte anno, int cilindrata){
        this.marca=marca;
        this.anno=anno;
        this.cilindrata=cilindrata;
    }

    /*
            Gerarchia

                Vehicle         (classe padre)
            /           \
         Car            Motorcycle
               (classi figlie)

- Le classi figlie "ereditano" gli attributi del padre.
Es. Vehicle definisce come attributi "marca, anno, cilindrata"


     */
}
