public class Main {
    public static void main(String[] args) {
        Garage garage = new Garage();
    }
}

/*

Crea una classe Main che implementi un esempio di esecuzione del programma
(es. qui --> crea un Garage / un oggetto di tipo Garage()

*/
