public class Main {
    public static void main(String[] args) {
        Garage garage = new Garage();

    }
}
