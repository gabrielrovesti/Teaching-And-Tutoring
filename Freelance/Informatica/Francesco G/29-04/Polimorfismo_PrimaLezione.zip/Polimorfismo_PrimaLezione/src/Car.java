public class Car {
private byte porte;
private boolean alimentazione; // 0=Benzina, 1=Diesel
}
