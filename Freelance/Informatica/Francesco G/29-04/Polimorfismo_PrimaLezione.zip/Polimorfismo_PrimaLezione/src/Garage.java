/*
 Si realizzi una applicazione java per la gestione di un garage secondo le specifiche:
il garage ha al max 15 posti ognuno dei quali è identificato da un num a partire da 0 e per motivi di capienza può ospitare solo auto moto e furgoni partendo dalla classe base veicolo a motore V; la si estenda, realizzando anche le classi che modellano le entità furgone (F) auto (A) e moto (M).
Ridefinire il metodo toString in modo che ogni entità possa esternalizzare in forma di stringa tutte le informazioni che la riguardano.
Si implementi una classe che modelli il garage sopradescritto offrendo le seguenti operazioni di gestione
1) immissione di un nuovo veicolo
2) estrazione dal garage del veicolo che occupa un determinato posto (ritornare l'istanza del veicolo stesso)
3) stampa della situazione corrente dei posti nel garage veicolo:
marca,anno,cilindrata;
auto:porte, alimentazione (diesel/benzina)
moto:tempi
furgone:capacità
*/

public class Garage {
    int[] posti = new int[15];

    // 1)
    public void insertVehicle(Vehicle nVehicle, String marca, byte anno, int cilindrata){
        for(int i=0;i<15;i++){
            if(posti[i] == 0){
                nVehicle = new Vehicle(marca, anno, cilindrata);
            }
            else System.out.println("Non ci sono posti rimanenti!");
        }
    }


    // 2)
    public void returnVehicle(int posto){
        System.out.println(posti[posto]);
    }

    // 3)

    public void print(){
        for(int i=0;i<=posti.length;i++){
            //se posti[i] contiene la classe Car allora stampa queste cose.
        }
    }

}