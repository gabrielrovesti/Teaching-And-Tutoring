public class Motorcycle extends Vehicle{
    private int tempi;

    Motorcycle(String marca, byte anno, int cilindrata, int tempi) {
        super(marca, anno, cilindrata);
        this.tempi=tempi;
    }
}
