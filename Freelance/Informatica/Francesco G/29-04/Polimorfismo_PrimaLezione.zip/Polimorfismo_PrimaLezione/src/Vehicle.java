public class Vehicle {
    private String marca;
    private byte anno;
    private int cilindrata;


    Vehicle(String marca, byte anno, int cilindrata){
        this.marca=marca;
        this.anno=anno;
        this.cilindrata=cilindrata;
    }
}
