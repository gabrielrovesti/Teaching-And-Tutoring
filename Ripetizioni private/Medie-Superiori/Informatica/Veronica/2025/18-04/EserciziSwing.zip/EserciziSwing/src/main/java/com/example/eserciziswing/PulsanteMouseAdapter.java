package com.example.eserciziswing;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PulsanteMouseAdapter extends MouseAdapter {
    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getButton() == MouseEvent.BUTTON3){ // Se click tasto dx
            JButton btn = (JButton) e.getSource();

            if(btn.isEnabled()){
                btn.setEnabled(false);
                btn.setBackground(Color.GRAY);
            }
            else{
                btn.setEnabled(true);

                // Se incrementa / decrementa, cambia colore
                String testo = btn.getText();
                if(testo.startsWith("+")){
                    btn.setBackground(new Color(144, 238, 144));
                }
                if(testo.startsWith("-")){
                    btn.setBackground(new Color(255, 182, 193));
                }
            }
        }
    }
}
