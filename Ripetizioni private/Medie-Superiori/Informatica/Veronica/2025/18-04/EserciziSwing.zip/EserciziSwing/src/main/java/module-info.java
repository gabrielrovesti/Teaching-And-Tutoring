module com.example.eserciziswing {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens com.example.eserciziswing to javafx.fxml;
    exports com.example.eserciziswing;
}