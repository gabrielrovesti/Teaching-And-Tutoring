package com.example.eserciziswing;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ContatoreApp extends JFrame {

    private JButton btnReset, btnMemorizza, btnRichiama;
    // Insieme bottoni per incremento e decremento
    private JButton[] btnIncrementa;
    private JButton[] btnDecrementa;
    // Etichette operazioni e target numerico da raggiungere
    private JLabel lblOperazione, lblTarget;

    // Valori default operazioni, target e memoria
    private int operazioni, targetValue, memoriaValue;

    // Display
    private DisplayContatore txtDisplay;

    // Costruttore - super / layout / init componenti, pannelli, ascoltatori

    public ContatoreApp() {
        super("Contatore");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Inizializzazione variabili (globali)
        operazioni = 0;
        memoriaValue = 0;
        targetValue = 100;

        // Inizializzazione componenti
        initComponenti();
        initPannelli();
        initAscoltatori();

        this.pack();
        this.setVisible(true);
    }

    private void initComponenti(){
        txtDisplay = new DisplayContatore();

        // Label, pulsanti, etc.

        lblOperazione = new JLabel("Operazioni: 0");
        lblOperazione.setFont(new Font("Sans-Serif", Font.BOLD, 14));

        lblTarget = new JLabel("Target: " + targetValue);
        lblTarget.setFont(new Font("Sans-Serif", Font.BOLD, 14));

        // Pulsanti incrementa e decrementa
        String[] incrementi = {"+1", "+5", "+10"};
        btnIncrementa = new JButton[incrementi.length];
        for (int i = 0; i < incrementi.length; i++) {
            btnIncrementa[i] = new JButton(incrementi[i]);
            btnIncrementa[i].setBackground(new Color(144, 238, 144));
        }

        String[] decrementi = {"-1", "-5", "-10"};
        btnDecrementa = new JButton[decrementi.length];
        for (int i = 0; i < decrementi.length; i++) {
            btnDecrementa[i] = new JButton(decrementi[i]);
            btnDecrementa[i].setBackground(new Color(255, 182, 193));
        }

        // Pulsanti di reset, memorizza e richiama
        btnReset = new JButton("Reset");
        btnReset.setBackground(new Color(255, 99, 71));

        btnMemorizza = new JButton("M+");
        btnMemorizza.setBackground(new Color(135, 206, 250));

        btnRichiama = new JButton("MR");
        btnRichiama.setBackground(new Color(135, 206, 250));

    }

    private void initPannelli(){
        Container contentPane = this.getContentPane();
        contentPane.setLayout(new BorderLayout(10, 10));

        // Nord - Display e contatori
        JPanel pnlNord = new JPanel(new BorderLayout(5, 5));
        pnlNord.setBorder(BorderFactory.createEmptyBorder(10, 10, 5, 10));

        pnlNord.add(txtDisplay, BorderLayout.CENTER);

        // Informazioni = Operazioni e target
        JPanel pnlInfo = new JPanel(new GridLayout(1, 2, 5, 0));
        pnlInfo.add(lblOperazione);
        pnlInfo.add(lblTarget);

        pnlNord.add(pnlInfo, BorderLayout.SOUTH);

        // Centro - Operazioni

        JPanel pnlCentro = new JPanel(new GridLayout(2, 3, 5, 5));
        pnlCentro.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

        for(int i = 0; i < btnIncrementa.length; i++){
            pnlCentro.add(btnIncrementa[i]);
            pnlCentro.add(btnDecrementa[i]);
        }

        // Sud - Funzioni (reset, memorizza, richiama)
        JPanel pnlSud = new JPanel(new FlowLayout
                (FlowLayout.CENTER, 10, 5));
        pnlSud.setBorder(BorderFactory.createEmptyBorder
                (5, 10, 10, 10));

        pnlSud.add(btnReset);
        pnlSud.add(btnMemorizza);
        pnlSud.add(btnRichiama);

        // Aggiungi al contenitore tutti i pannelli
        contentPane.add(pnlNord, BorderLayout.NORTH);
        contentPane.add(pnlCentro, BorderLayout.CENTER);
        contentPane.add(pnlSud, BorderLayout.SOUTH);
    }

    private void initAscoltatori(){
        // Ascoltatore 1 - Bottone reset

        btnReset.addActionListener(new AscoltaOperazioni(){
            @Override
            public void actionPerformed(ActionEvent e) {
                // Azzera display
                txtDisplay.resetValore();
                operazioni = 0;
                lblOperazione.setText("Operazioni: " + operazioni);
            }
        });

        // Ascoltatore 2 - Bottoni incremento / decremento
        AscoltaOperazioni ascoltaOp = new AscoltaOperazioni();
        for(int i = 0; i < btnIncrementa.length; i++){
            btnIncrementa[i].addActionListener(ascoltaOp);
            btnDecrementa[i].addActionListener(ascoltaOp);
        }

        // Ascoltatore 3 - Bottoni memorizza / richiama
        AscoltaPulsanti ascoltaMemoria = new AscoltaPulsanti(this);
        btnMemorizza.addActionListener(ascoltaMemoria);
        btnRichiama.addActionListener(ascoltaMemoria);

        // Aggiunta MouseListener per blocco / sblocco pulsanti
        PulsanteMouseAdapter mouseAdapter = new PulsanteMouseAdapter();
        for(int i = 0; i < btnIncrementa.length; i++){
            btnIncrementa[i].addMouseListener(mouseAdapter);
            btnDecrementa[i].addMouseListener(mouseAdapter);
        }
    }

        // Getter / setter per variabili globali (memoria, display)
        public DisplayContatore getDisplay() {
            return txtDisplay;
        }
        public void setMemoriaValue(int value) {
            this.memoriaValue = value;
        }
        public int getMemoriaValue() {
            return memoriaValue;
        }

        private class AscoltaOperazioni implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e){
            // Capire che tipo di comando viene svolto
            // Visualizza valore su display
            // Controlla se target raggiunto

            JButton btn = (JButton) e.getSource();
            String operazione = btn.getText();

            int valore = txtDisplay.getValore();

            switch(operazione){
                case "+1":
                    valore++;
                    break;
                case "+5":
                    valore += 5;
                    break;
                case "+10":
                    valore += 10;
                    break;
                case "-1":
                    valore--;
                    break;
                case "-5":
                    valore -= 5;
                    break;
                case "-10":
                    valore -= 10;
                    break;
            }

            // Set valore su display e aumento operazioni
            txtDisplay.setValore(valore);
            operazioni++;
            lblOperazione.setText("Operazioni: " + operazioni);

            // Controllo se target raggiunto
            if(valore == targetValue){
                JOptionPane.showMessageDialog(ContatoreApp.this, "Target raggiunto: " + targetValue + "!",
                        "Target raggiunto", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        new ContatoreApp();
    }
}