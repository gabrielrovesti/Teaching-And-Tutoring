package com.example.eserciziswing;

import javax.swing.*;
import java.awt.*;

public class DisplayContatore extends JTextField {
    private int valore;

    public DisplayContatore() {
        super("0");
        this.valore = 0;

        // Set grafico
        setFont(new Font("Monospaced", Font.BOLD, 36));
        setHorizontalAlignment(SwingConstants.CENTER);
        setEditable(false);
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.BLACK, 2),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)));

        setPreferredSize(new Dimension(200, 60));
    }

    public void setValore(int valore){
        this.valore = valore;
        setText(String.valueOf(valore));

        // Cambia colore del testo in base al valore
        if (valore > 0) {
            setForeground(new Color(0, 128, 0)); // Dark green
        } else if (valore < 0) {
            setForeground(new Color(178, 34, 34)); // Firebrick
        } else {
            setForeground(Color.BLACK);
        }
    }

    public int getValore(){
        return valore;
    }

    public void resetValore(){
        setValore(0);
    }
}
