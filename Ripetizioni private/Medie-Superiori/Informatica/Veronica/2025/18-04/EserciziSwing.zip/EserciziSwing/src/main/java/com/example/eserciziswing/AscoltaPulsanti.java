package com.example.eserciziswing;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AscoltaPulsanti implements ActionListener {
    private ContatoreApp app;

    public AscoltaPulsanti(ContatoreApp app){
        this.app = app;
    }

    @Override
    public void actionPerformed(ActionEvent e){
        String comando = e.getActionCommand();

        if(comando.equals("M+")){
            app.setMemoriaValue(app.getDisplay().getValore());
        }
        else if(comando.equals("MR")){
            app.getDisplay().setValore(app.getMemoriaValue());
        }
    }
}
