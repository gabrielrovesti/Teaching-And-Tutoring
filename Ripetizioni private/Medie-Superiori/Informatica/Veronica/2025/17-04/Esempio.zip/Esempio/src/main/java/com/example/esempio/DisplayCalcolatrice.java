package com.example.esempio;

import java.awt.*;
import javax.swing.*;

public class DisplayCalcolatrice extends JTextField{
    // Costruttore
    public DisplayCalcolatrice() {
        super("0");
        this.setFont(new Font("Arial", Font.BOLD, 24));
        this.setHorizontalAlignment(SwingConstants.RIGHT);
        this.setEditable(false);
        this.setBackground(new Color(230, 255, 230));
    }
    // Aggiungi numero sul display
    public void aggiungiNumero(int numero) {
        String testo = this.getText();
        if (testo.equals("0")) {
            this.setText(Integer.toString(numero));
        } else {
            this.setText(testo + numero);
        }
    }
}
