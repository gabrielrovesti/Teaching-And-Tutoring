package com.example.esempio;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AscoltaMemoria implements ActionListener {
    private Calcolatrice calcolatrice;

    public AscoltaMemoria(Calcolatrice calcolatrice) {
        this.calcolatrice = calcolatrice;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("M+")) {
            double valore = calcolatrice.getDisplayValue();
            calcolatrice.setMemoria(valore);
            calcolatrice.aggiornaContatore();
        } else if (e.getActionCommand().equals("MR")) {
            double memoriaValore = calcolatrice.getMemoria();
            calcolatrice.setDisplayValue(memoriaValore);
        }
    }
}
