package com.example.esempio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Calcolatrice extends JFrame {

    // Display
    // Information hiding = private
    private DisplayCalcolatrice display;
    private JLabel lblContatore;
    // Bottoni operazioni matematiche, cancella e memoria
    private JButton btnSomma, btnSottrazione, btnMoltiplicazione, btnDivisione;
    private JButton btnUguale, btnCancella, btnMemoria, btnRichiama;
    private JButton[] btnNumeri;
    private int contatoreClic = 0;
    private double numero1 = 0;
    private double memoria = 0;
    private String operazioneCorrente = "";
    private boolean nuovoNumero = true;

    // Costruttore
    public Calcolatrice(){
        super("Calcolatrice");
        // Caricare la GUI e gestisci il caso chiusura (automatico)
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        // Lanciare init di tutto = componenti / pannelli / ascoltatori
        initComponenti();
        initPannelli();
        initAscoltatori();

        // Rendere visibile la finestra e poi lanciarla
        this.pack();
        this.setVisible(true);
    }

    private void initComponenti() {
        // Inizializzare display - numeri - label - bottoni
        display = new DisplayCalcolatrice();
        btnNumeri = new JButton[10];

        // 10 bottoni con numero da inizializzare
        for(int i = 0; i < 10; i++){
            btnNumeri[i] = new JButton(String.valueOf(i)); // Prendimi quel valore in quella posizione
            btnNumeri[i].setFont(new Font("Arial", Font.BOLD, 16));
        }

        btnSomma = new JButton("+");
        btnSottrazione = new JButton("-");
        btnMoltiplicazione = new JButton("*");
        btnDivisione = new JButton("/");
        btnUguale = new JButton("=");
        btnCancella = new JButton("C");
        btnMemoria = new JButton("M");
        btnRichiama = new JButton("MR");

        // Label del contatore
        lblContatore = new JLabel("Operazioni: 0");
        lblContatore.setHorizontalAlignment(JLabel.CENTER);
    }

    private void initPannelli(){
        // Pannello nord - JPanel
        JPanel pnlNord = new JPanel(new BorderLayout());
        pnlNord.add(display, BorderLayout.CENTER);
        pnlNord.add(lblContatore, BorderLayout.SOUTH);

        // Pannello centrale (numeri)
        JPanel pnlCentro = new JPanel(new GridLayout(4, 3, 5, 5));
        for (int i = 1; i <= 9; i++) {
            pnlCentro.add(btnNumeri[i]);
        }
        pnlCentro.add(btnCancella);
        pnlCentro.add(btnNumeri[0]);
        pnlCentro.add(btnUguale);

        // Pannello operazioni (Est)
        JPanel pnlEst = new JPanel(new GridLayout(4, 1, 5, 5));
        pnlEst.add(btnSomma);
        pnlEst.add(btnSottrazione);
        pnlEst.add(btnMoltiplicazione);
        pnlEst.add(btnDivisione);

        // Pannello memoria (Sud)
        JPanel pnlSud = new JPanel(new GridLayout(1, 2, 5, 5));
        pnlSud.add(btnMemoria);
        pnlSud.add(btnRichiama);

        Container contentPane = this.getContentPane();
        contentPane.setLayout(new BorderLayout(5, 5));

        contentPane.add(pnlNord, BorderLayout.NORTH);
        contentPane.add(pnlCentro, BorderLayout.CENTER);
        contentPane.add(pnlEst, BorderLayout.EAST);
        contentPane.add(pnlSud, BorderLayout.SOUTH);

        // Setting bordi
        pnlNord.setBorder(BorderFactory.createEmptyBorder(10, 10, 5, 10));
        pnlCentro.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 5));
        pnlEst.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 10));
        pnlSud.setBorder(BorderFactory.createEmptyBorder(5, 10, 10, 10));
    }

    private void initAscoltatori() {
        // ActionListener
        for(int i = 0; i < 10; i++){
            final int numero = i;
            btnNumeri[i].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (nuovoNumero) {
                        display.setText("");
                        nuovoNumero = false;
                    }
                    display.aggiungiNumero(numero);
                }
            });
        }

        // Ascoltatore per le operazioni (classe interna che estende ActionListener)
        AscoltaOperazioni ascoltaOp = new AscoltaOperazioni();
        btnSomma.addActionListener(ascoltaOp);
        btnSottrazione.addActionListener(ascoltaOp);
        btnMoltiplicazione.addActionListener(ascoltaOp);
        btnDivisione.addActionListener(ascoltaOp);
        btnUguale.addActionListener(ascoltaOp);
        btnCancella.addActionListener(ascoltaOp);

        // Ascoltatore per la memoria (classe esterna)
        AscoltaMemoria ascoltaMem = new AscoltaMemoria(this);
        btnMemoria.addActionListener(ascoltaMem);
        btnRichiama.addActionListener(ascoltaMem);
    }

    // Aggiornare contatore / Mostra-setta valore display ai numeri / Setmemoria

    public void aggiornaContatore() {
        contatoreClic++;
        lblContatore.setText("Operazioni: " + contatoreClic);
    }

    public double getDisplayValue() {
        try {
            return Double.parseDouble(display.getText());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    public void setDisplayValue(double value) {
        display.setText(String.format("%.2f", value).replace(",", "."));
        nuovoNumero = true;
    }

    public void setMemoria(double valore) {
        this.memoria = valore;
    }

    public double getMemoria() {
        return this.memoria;
    }

    private class AscoltaOperazioni implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e){
            // Prendere il comando (cancella + uguale) = unici comandi non standard
            String comando = e.getActionCommand();

            if (comando.equals("C")) {
                display.setText("0");
                numero1 = 0;
                operazioneCorrente = "";
                nuovoNumero = true;
                return;
            }

            if(comando.equals("=")){
                double numero2 = getDisplayValue();
                double risultato = calcolaRisultato(numero1, numero2, operazioneCorrente);
                setDisplayValue(risultato);
                operazioneCorrente = "";
                aggiornaContatore();
                return;
            }

            // Aggiorna display
            numero1 = getDisplayValue();
            operazioneCorrente = comando;
            nuovoNumero = true;
        }

        private double calcolaRisultato(double num1, double num2, String operazione){
            //if(operazione.equals("+")){}
            switch (operazione) {
                case "+":
                    return num1 + num2;
                case "-":
                    return num1 - num2;
                case "×":
                    return num1 * num2;
                case "÷":
                    if (num2 == 0) {
                        JOptionPane.showMessageDialog(null, "Divisione per zero non consentita", "Errore", JOptionPane.ERROR_MESSAGE);
                        return 0;
                    }
                    return num1 / num2;
                default:
                    return num2;
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Calcolatrice();
            }
        });
    }
}