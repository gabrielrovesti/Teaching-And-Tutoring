module com.example.esempio {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens com.example.esempio to javafx.fxml;
    exports com.example.esempio;
}