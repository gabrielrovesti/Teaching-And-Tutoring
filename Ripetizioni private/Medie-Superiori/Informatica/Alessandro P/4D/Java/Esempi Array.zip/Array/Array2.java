import java.util.Arrays;

public class Array2 {

    // Metodo per la ricerca lineare
    public static int linearSearch(int[] array, int target) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == target) {
                return i; // Restituisce la locazione di memoria se l'elemento è trovato
            }
        }
        return -1; // Restituisce -1 se l'elemento non è presente nell'array
    }

    // Metodo per la ricerca binaria (l'array deve essere ordinato)
    public static int binarySearch(int[] array, int target) {
        int left = 0;
        int right = array.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (array[mid] == target) {
                return mid; // Restituisce la locazione di memoria se l'elemento è trovato
            } else if (array[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return -1; // Restituisce -1 se l'elemento non è presente nell'array
    }

    public static void main(String[] args) {
        int[] myArray = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

        int targetElement = 7;

        // Esempio di utilizzo della ricerca lineare
        int linearResult = linearSearch(myArray, targetElement);
        System.out.println("Ricerca Lineare: Elemento " + targetElement +
                           (linearResult != -1 ? " trovato alla posizione " + linearResult : " non trovato"));

        // Esempio di utilizzo della ricerca binaria
        // L'array deve essere ordinato per utilizzare la ricerca binaria
        Arrays.sort(myArray);
        int binaryResult = binarySearch(myArray, targetElement);
        System.out.println("Ricerca Binaria: Elemento " + targetElement +
                           (binaryResult != -1 ? " trovato alla posizione " + binaryResult : " non trovato"));
    }
}
