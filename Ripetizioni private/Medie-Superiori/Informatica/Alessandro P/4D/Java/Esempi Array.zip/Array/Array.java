/*
Scrivere un metodo della class Array che faccia la ricerca LINEARE di un Item e restituisca la relativa locazione di memoria.
Scrivere un metodo della class Array che faccia la ricerca BINARIA di un Item e restituisca la relativa locazione di memoria.
*/

class Array{
    public static void main(String[] args){
        int[] array = {1,2,3,4,5,6,7,8,9,10};
        System.out.println(linearSearch(array, 5));
        System.out.println(binarySearch(array, 5));
    }

    public static int linearSearch(int[] array, int item){
        for(int i = 0; i < array.length; i++){
            if(array[i] == item){
                return i;
            }
        }
        return -1;
    }

    public static int binarySearch(int[] array, int item){
        int low = 0;
        int high = array.length - 1;
        int mid;

        while(low <= high){
            mid = (low + high) / 2;
            if(array[mid] == item){
                return mid;
            }else if(array[mid] < item){
                low = mid + 1;
            }else{
                high = mid - 1;
            }
        }
        return -1;
    }
}