import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GUI {
    private JFrame frame;
    private JLabel lblTitolo;
    private JButton[] pulsanti;
    private String currentPlayer = "X";

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                GUI window = new GUI();
                window.frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public GUI() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Tris");
        frame.setResizable(false);
        frame.setSize(500, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        lblTitolo = new JLabel("TRIS");
        lblTitolo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitolo.setFont(new Font("Tahoma", Font.BOLD, 40));
        lblTitolo.setBounds(10, 11, 464, 42);
        frame.getContentPane().add(lblTitolo);

        pulsanti = new JButton[9];

        for (int i = 0; i < pulsanti.length; i++) {
            pulsanti[i] = new JButton(" ");
            pulsanti[i].setFont(new Font("Tahoma", Font.BOLD, 40));
            pulsanti[i].setBounds((i % 3) * 150 + 50, (i / 3) * 130 + 80, 120, 120);
            pulsanti[i].addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    JButton temp = (JButton)e.getComponent();
                    int x = (temp.getX() - 50) / 120;
                    int y = (temp.getY() - 80) / 120;
                    gestioneTris(x, y);
                }
            });
            frame.getContentPane().add(pulsanti[i]);
        }
    }

    private void gestioneTris(int x, int y) {
        if (pulsanti[y*3+x].getText().equals(" ")) {
            pulsanti[y*3+x].setText(currentPlayer);
            checkWin();
            currentPlayer = (currentPlayer.equals("X")) ? "O" : "X";
        }
    }

    private void checkWin() {
        String[][] board = new String[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                board[i][j] = pulsanti[i*3+j].getText();
            }
        }

        for (int i = 0; i < 3; i++) {
            if (board[i][0].equals(board[i][1]) && board[i][1].equals(board[i][2]) && !board[i][0].equals(" ")) {
                endGame(board[i][0] + " vince!");
                return;
            }
            if (board[0][i].equals(board[1][i]) && board[1][i].equals(board[2][i]) && !board[0][i].equals(" ")) {
                endGame(board[0][i] + " vince!");
                return;
            }
        }

        if (board[0][0].equals(board[1][1]) && board[1][1].equals(board[2][2]) && !board[0][0].equals(" ")) {
            endGame(board[0][0] + " vince!");
            return;
        }
        if (board[0][2].equals(board[1][1]) && board[1][1].equals(board[2][0]) && !board[0][2].equals(" ")) {
            endGame(board[0][2] + " vince!");
            return;
        }

        boolean tie = true;
        for (int i = 0; i < 9; i++) {
            if (pulsanti[i].getText().equals(" ")) {
                tie = false;
                break;
            }
        }
        if (tie) {
            endGame("Pareggio!");
        }
    }

    private void endGame(String message) {
        JOptionPane.showMessageDialog(frame, message);
        for (int i = 0; i < 9; i++) {
            pulsanti[i].setText(" ");
        }
    }
}