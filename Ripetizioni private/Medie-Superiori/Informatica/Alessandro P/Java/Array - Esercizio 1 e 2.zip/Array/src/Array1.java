public class Array1 {
    // dichiarazione di max (1)
    // dichiarazione del vettore di interi
    // ciclo per vedere i contenuti del vettore prima che sia popolato

    int max = 10; // 1
    int[] vettore = new int[10];
    // oppure int[] vettore;

    // metodo di attraversamento array
    // scrittura funzione = visibilità (public) / tipo di ritorno (nulla = void) / nome metodo / parametri (nelle tonde)
    public void attraversaArray(int[] vett) {
        for (int i = 0; i < vett.length; i++) {
            System.out.println(i + "° Elemento con valore \"" + vett[i] + "\"");
        }
    }

    public int[] popolaArray(int[] vett, int numItem, int base){
        // passi un vettore, che itera fino al numero di elementi (numItem)
        // e poi riempi il vettore con l'elemento base (facendo dei calcoli con quello)
        for (int i=0; i < numItem ; i++){
            vett[i] = i + base; // uso base con un calcolo di qualche tipo per riempire il vettore
        }
        return vett;
    }

    // metodo principale o costruttore
    public static void main(String[] args) {
        int max = 10;
        Array1 array1 = new Array1();
        // esercizio1
        System.out.println("Esercizio 1");
        array1.attraversaArray(array1.vettore); // passo un array per scorrerlo

        // esercizio2
        System.out.println("Esercizio 2");
        array1.vettore = array1.popolaArray(array1.vettore, max / 2, 0); // aggiorna il vettore con i nuovi valori
        array1.attraversaArray(array1.vettore);


    }
}
