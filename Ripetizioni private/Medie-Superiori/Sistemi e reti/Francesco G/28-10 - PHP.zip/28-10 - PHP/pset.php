<?php
    $s='localhost';
    $u='root';
    $p='';
    $d='Scuola';
?>