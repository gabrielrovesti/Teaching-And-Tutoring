<?php
    include('pset.php');

    $c=mysqli_connect($s,$u,$p,$d);
?>