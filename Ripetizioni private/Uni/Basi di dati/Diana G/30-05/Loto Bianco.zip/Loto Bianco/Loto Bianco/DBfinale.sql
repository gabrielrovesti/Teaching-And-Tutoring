DROP TABLE IF EXISTS accesso CASCADE;
DROP TABLE IF EXISTS utilizzo CASCADE;
DROP TABLE IF EXISTS trattamento CASCADE;
DROP TABLE IF EXISTS p_comp CASCADE;
DROP TABLE IF EXISTS composizione CASCADE;
DROP TABLE IF EXISTS prodotto CASCADE;
DROP TABLE IF EXISTS fattura CASCADE;
DROP TABLE IF EXISTS azienda CASCADE;
DROP TABLE IF EXISTS massaggio CASCADE;
DROP TABLE IF EXISTS pulizia_viso CASCADE;
DROP TABLE IF EXISTS addetto_at CASCADE;
DROP TABLE IF EXISTS specialista CASCADE;
DROP TABLE IF EXISTS segretario CASCADE;
DROP TABLE IF EXISTS dipendente CASCADE;
DROP TABLE IF EXISTS area_termale CASCADE;
DROP TABLE IF EXISTS abbonato CASCADE;
DROP TABLE IF EXISTS cliente CASCADE;

--creazione tabelle

CREATE TABLE cliente (
    cf VARCHAR(16) NOT NULL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cognome VARCHAR(100) NOT NULL,
    via VARCHAR(100) NOT NULL,
    citta VARCHAR(100) NOT NULL,
    cap VARCHAR(10) NOT NULL,
        telefono VARCHAR UNIQUE NOT NULL
);

CREATE TABLE abbonato (
        cf VARCHAR(16) NOT NULL PRIMARY KEY,
    numero_carta INT NOT NULL,
    data_iscrizione DATE NOT NULL,
    FOREIGN KEY (cf) REFERENCES cliente(cf)
);

CREATE TABLE dipendente (
        cf VARCHAR(16) NOT NULL PRIMARY KEY,
        nome VARCHAR(100) NOT NULL,
    cognome VARCHAR(100) NOT NULL,
        telefono VARCHAR UNIQUE NOT NULL,
        stipendio DECIMAL(7, 2) NOT NULL
        );

DROP TYPE IF EXISTS nome_enum;
CREATE TYPE nome_enum AS ENUM ('Piscina termale', 'Bagno turco', 'Vasca idromassaggio', 'Grotta di sale', 'Sauna finlandese');

CREATE TABLE area_termale (
    id_zona INT PRIMARY KEY,
    nome_zona nome_enum NOT NULL,
    orario_apertura TIME NOT NULL,
    orario_chiusura TIME NOT NULL
);

CREATE TABLE segretario (
        cf_seg VARCHAR(16) NOT NULL PRIMARY KEY,
        FOREIGN KEY (cf_seg) REFERENCES dipendente(cf)
);

DROP TYPE IF EXISTS titolo_enum;
CREATE TYPE titolo_enum AS ENUM ('Massaggiatore Olistico', 'Operatrice Dermocosmetica', 'Esperta in Pulizia Profonda del Viso', 'Operatore Certificato in Pressoterapia');

CREATE TABLE specialista (
        cf_spe VARCHAR(16) NOT NULL PRIMARY KEY,
    titolo titolo_enum NOT NULL,
        FOREIGN KEY (cf_spe) REFERENCES dipendente(cf)
);

CREATE TABLE addetto_at (
        cf_add VARCHAR(16) NOT NULL,
        turno TEXT NOT NULL CHECK (turno IN ('Mattina', 'Pomeriggio', 'Sera')),
        zona INT NOT NULL,
        PRIMARY KEY (cf_add, turno),
        FOREIGN KEY (cf_add) REFERENCES dipendente(cf),
        FOREIGN KEY (zona) REFERENCES area_termale(id_zona)
);

CREATE TABLE azienda (
        piva VARCHAR (20) PRIMARY KEY,
        nome VARCHAR(25) NOT NULL,
        sede VARCHAR(100) NOT NULL
);

CREATE TABLE prodotto (
        marca VARCHAR(50) NOT NULL,
        nome VARCHAR(70) NOT NULL,
        data_scadenza DATE NOT NULL,
        azienda VARCHAR(20) NOT NULL,
        cf_seg VARCHAR(16) NOT NULL,
        PRIMARY KEY (marca, nome),
        FOREIGN KEY (azienda) REFERENCES azienda(piva),
        FOREIGN KEY (cf_seg) REFERENCES segretario (cf_seg)
);

CREATE TABLE composizione (
        ingrediente TEXT NOT NULL PRIMARY KEY
);

CREATE TABLE p_comp (
        marca VARCHAR(50) NOT NULL,
        nome VARCHAR(70) NOT NULL,
        ingrediente TEXT NOT NULL,
        PRIMARY KEY (marca, nome, ingrediente),
        FOREIGN KEY (marca, nome) REFERENCES prodotto (marca, nome),
        FOREIGN KEY (ingrediente) REFERENCES composizione (ingrediente)
);

CREATE TABLE fattura (
    numero INT NOT NULL PRIMARY KEY,
    mod_pagamento VARCHAR(40) NOT NULL,
        cf_seg VARCHAR(16) NOT NULL,
        cf_cliente VARCHAR(16) NOT NULL,
        FOREIGN KEY (cf_seg) REFERENCES segretario(cf_seg),
    FOREIGN KEY (cf_cliente) REFERENCES cliente(cf)
);

CREATE TABLE trattamento (
    codice INT NOT NULL,
    data_ora TIMESTAMP NOT NULL,
    cf_specialista VARCHAR(16) NOT NULL,
    prezzo DECIMAL(6, 2) NOT NULL,
    numero_fattura INT NOT NULL,
    cf_cliente VARCHAR(16) NOT NULL,
    PRIMARY KEY (codice),
    UNIQUE (cf_specialista, data_ora),
        FOREIGN KEY (cf_cliente) REFERENCES cliente(cf),
    FOREIGN KEY (cf_specialista) REFERENCES specialista(cf_spe),
    FOREIGN KEY (numero_fattura) REFERENCES fattura(numero),
        FOREIGN KEY (cf_cliente) REFERENCES cliente(cf)
);

DROP TYPE IF EXISTS tipologia_enum;
CREATE TYPE tipologia_enum AS ENUM ('secca', 'normale', 'grassa');

CREATE TABLE pulizia_viso (
    codice INT NOT NULL,
    tipologia tipologia_enum NOT NULL,
    PRIMARY KEY (codice),
    FOREIGN KEY (codice) REFERENCES trattamento(codice)
);

CREATE TABLE massaggio (
    codice INT NOT NULL,
    zona VARCHAR(20) NOT NULL,
    durata INT NOT NULL, -- durata in minuti
    PRIMARY KEY (codice),
    FOREIGN KEY (codice) REFERENCES trattamento(codice)
);

CREATE TABLE utilizzo (
    codice_trattamento INT NOT NULL,
    marca_prodotto VARCHAR(50) NOT NULL,
    nome_prodotto VARCHAR(100) NOT NULL,
    PRIMARY KEY (codice_trattamento, marca_prodotto, nome_prodotto),
    FOREIGN KEY (codice_trattamento) REFERENCES trattamento(codice),
    FOREIGN KEY (marca_prodotto, nome_prodotto) REFERENCES prodotto(marca, nome)
);

CREATE TABLE accesso (
        cf_abb VARCHAR (16) NOT NULL,
        id_zona INT NOT NULL,
        giorno DATE NOT NULL,
        PRIMARY KEY (cf_abb, id_zona),
        FOREIGN KEY (cf_abb) REFERENCES abbonato(cf),
        FOREIGN KEY (id_zona) REFERENCES area_termale(id_zona)
);

-- indici


-- popolamento con dati per le query


INSERT INTO cliente (cf, nome, cognome, via, citta, cap, telefono) VALUES
('ZGOMRA85C10F205Y', 'Maria', 'Zago', 'Via Roma 10', 'Milano', '20121', '3201234567'),
('SPSLGU90A01L219U', 'Luigi', 'Esposito', 'Viale delle Rose 25', 'Torino', '10121', '3399876543'),
('CNTFNC78B15D612T', 'Francesco', 'Conti', 'Corso Italia 50', 'Firenze', '50123', '3314567890'),
('NGLSRA92D50F839P', 'Sara', 'Neri', 'Via Garibaldi 3', 'Napoli', '80134', '3286543210'),
('MNTGPP88C30A662E', 'Giuseppe', 'Monti', 'Via Verdi 12', 'Bologna', '40121', '3271122334');


INSERT INTO azienda (piva, nome, sede) VALUES
('IT12345678901', 'Lancôme', 'Parigi, Francia'),
('IT23456789012', 'Avène', 'Avène, Francia'),
('IT34567890123', 'La Roche-Posay', 'La Roche-Posay, Francia'),
('IT45678901234', 'Bioline Jatò', 'Trento, Italia'),
('IT56789012345', 'Nuxe', 'Parigi, Francia'),
('IT67890123456', 'Sothys Paris', 'Brive-la-Gaillarde, Francia'),
('IT78901234567', 'Guam', 'Riccione, Italia'),
('IT89012345678', 'CeraVe', 'New York, USA');


INSERT INTO dipendente (cf, nome, cognome, telefono, stipendio) VALUES
('DPRNNL09E41D171D', 'Antonella', 'Di Peri', '3192812408', '1800.00'),
('BRNPRD86E01G471P', 'Pietro', 'Bruni', '388279183', '2000.00'),
('RSSMGH00A01F556I', 'Margherita', 'Rossi', '387065033', '2100.00'),
('VRDMRC90A01F556M', 'Marco', 'Verdi', '3197411900', '1990.00'),
('RZZPLA90A01F556F', 'Paolo', 'Rizzi', '3732233061', '1600.00'),
('BNCNNA00A01F556N', 'Anna', 'Bianchi', '3193298288', '1900.00'),
('FRRSRA00A01F556A', 'Sara', 'Ferrari', '3191830110', '1495.00'),
('LNGMIA99C03G224X', 'Mia', 'Longhi', '397381456', '1940.00'),
('MSSCDN80A01H501G', 'Massimo', 'Cardin', '3932555743', '1400.00'),
('LNECTN80M51H501N', 'Elena', 'Contin', '3545479291', '1890.00'),
('FRLGLI99H01I140I', 'Giulio', 'Furlan', '3495551709', '2000.00');


INSERT INTO specialista (cf_spe, titolo) VALUES
('BRNPRD86E01G471P', 'Massaggiatore Olistico'),
('RSSMGH00A01F556I', 'Esperta in Pulizia Profonda del Viso'),
('VRDMRC90A01F556M', 'Operatore Certificato in Pressoterapia'),
('LNGMIA99C03G224X', 'Operatrice Dermocosmetica');


INSERT INTO area_termale (id_zona, nome_zona, orario_apertura, orario_chiusura) VALUES
('1', 'Piscina termale', '08:00', '20:00'),
('2', 'Sauna finlandese', '09:00', '21:00'),
('3', 'Bagno turco', '10:00', '22:00'),
('4', 'Grotta di sale', '11:00', '18:00'),
('5', 'Vasca idromassaggio', '08:30', '20:30');


INSERT INTO addetto_at (cf_add, turno, zona) VALUES
('DPRNNL09E41D171D', 'Mattina', '1'),
('DPRNNL09E41D171D', 'Sera', '1'),
('RZZPLA90A01F556F', 'Sera', '2'),
('BNCNNA00A01F556N', 'Mattina', '3'),
('BNCNNA00A01F556N', 'Pomeriggio', '3'),
('FRRSRA00A01F556A', 'Mattina', '4'),
('MSSCDN80A01H501G', 'Sera', '5');


INSERT INTO segretario (cf_seg) VALUES
('LNECTN80M51H501N'),
('FRLGLI99H01I140I');


INSERT INTO prodotto (marca, nome, data_scadenza, azienda, cf_seg) VALUES
('Lancôme', 'Advanced Génifique Serum', '2025-06-01', 'IT12345678901', 'LNECTN80M51H501N'),
('Avène', 'Cleanance Comedomed', '2025-05-30', 'IT23456789012', 'FRLGLI99H01I140I'),
('La Roche-Posay', 'Effaclar Duo', '2027-01-31', 'IT34567890123', 'LNECTN80M51H501N'),
('Bioline Jatò', 'Pure Gel Cleansing', '2027-01-31', 'IT45678901234', 'LNECTN80M51H501N'),
('Nuxe', 'Huile Prodigieuse', '2030-06-30', 'IT56789012345', 'LNECTN80M51H501N'),
('Sothys Paris', 'Thermo-Active Salt Scrub', '2026-12-31', 'IT67890123456', 'FRLGLI99H01I140I'),
('Guam', 'Fango Termale Anticellulite', '2030-01-01', 'IT78901234567', 'FRLGLI99H01I140I'),
('CeraVe', 'Crema Viso Idratante', '2025-02-01', 'IT89012345678', 'FRLGLI99H01I140I');

INSERT INTO composizione (ingrediente) VALUES
('Acido ialuronico'),
('Bifidus probiotici'),
('Vitamina C'),
('Acqua termale'),
('Acido salicilico'),
('Niacinamide'),
('Ceramidi'),
('Acido glicolico'),
('Aloe vera'),
('Estratto di camomilla'),
('Olio di macadamia'),
('Vitamina E'),
('Olio di tsubaki'),
('Sale marino'),
('Oli essenziali'),
('Burro di karitè'),
('Alghe marine'),
('Argilla'),
('Caffeina');


INSERT INTO p_comp (marca, nome, ingrediente) VALUES
('Lancôme', 'Advanced Génifique Serum', 'Acido ialuronico'),
('Lancôme', 'Advanced Génifique Serum', 'Bifidus probiotici'),
('Lancôme', 'Advanced Génifique Serum', 'Vitamina C'),
('Avène', 'Cleanance Comedomed', 'Acqua termale'),
('Avène', 'Cleanance Comedomed', 'Acido salicilico'),
('Avène', 'Cleanance Comedomed', 'Niacinamide'),
('La Roche-Posay', 'Effaclar Duo', 'Niacinamide'),
('La Roche-Posay', 'Effaclar Duo', 'Acido salicilico'),
('La Roche-Posay', 'Effaclar Duo', 'Ceramidi'),
('Bioline Jatò', 'Pure Gel Cleansing', 'Acido glicolico'),
('Bioline Jatò', 'Pure Gel Cleansing', 'Aloe vera'),
('Bioline Jatò', 'Pure Gel Cleansing', 'Estratto di camomilla'),
('Nuxe', 'Huile Prodigieuse', 'Olio di macadamia'),
('Nuxe', 'Huile Prodigieuse', 'Vitamina E'),
('Nuxe', 'Huile Prodigieuse', 'Olio di tsubaki'),
('Sothys Paris', 'Thermo-Active Salt Scrub', 'Sale marino'),
('Sothys Paris', 'Thermo-Active Salt Scrub', 'Oli essenziali'),
('Sothys Paris', 'Thermo-Active Salt Scrub', 'Burro di karitè'),
('Guam', 'Fango Termale Anticellulite', 'Alghe marine'),
('Guam', 'Fango Termale Anticellulite', 'Argilla'),
('Guam', 'Fango Termale Anticellulite', 'Caffeina'),
('CeraVe', 'Crema Viso Idratante', 'Ceramidi'),
('CeraVe', 'Crema Viso Idratante', 'Acido ialuronico'),
('CeraVe', 'Crema Viso Idratante', 'Niacinamide');


INSERT INTO fattura (numero, cf_cliente, mod_pagamento, cf_seg) VALUES
('1000', 'ZGOMRA85C10F205Y', 'Carta di debito', 'FRLGLI99H01I140I'),
('1001', 'SPSLGU90A01L219U', 'Carta di credito', 'FRLGLI99H01I140I'),
('1002', 'ZGOMRA85C10F205Y', 'Contanti', 'LNECTN80M51H501N'),
('1003', 'CNTFNC78B15D612T', 'Contanti', 'LNECTN80M51H501N'),
('1004', 'CNTFNC78B15D612T', 'Contanti', 'LNECTN80M51H501N'),
('1005', 'NGLSRA92D50F839P', 'Bonifico', 'LNECTN80M51H501N'),
('1006', 'MNTGPP88C30A662E', 'Carta di debito', 'FRLGLI99H01I140I'),
('1007', 'SPSLGU90A01L219U', 'Bonifico', 'FRLGLI99H01I140I');


INSERT INTO trattamento (codice, data_ora, cf_specialista, prezzo, numero_fattura, cf_cliente) VALUES
('1', '2024-06-05 9:00:00', 'RSSMGH00A01F556I', '200.00', '1000', 'ZGOMRA85C10F205Y'),
('2', '2025-01-10 10:20:00', 'RSSMGH00A01F556I', '110.00', '1001', 'SPSLGU90A01L219U'),
('3', '2025-01-30 10:30:00', 'VRDMRC90A01F556M', '50.00', '1002', 'ZGOMRA85C10F205Y'),
('4', '2025-01-30 11:00:00', 'BRNPRD86E01G471P', '40.00', '1002', 'ZGOMRA85C10F205Y'),
('5', '2025-03-17 10:00:00', 'BRNPRD86E01G471P', '150.00', '1003', 'CNTFNC78B15D612T'),
('6', '2025-05-10 14:30:00', 'LNGMIA99C03G224X', '70.00', '1004', 'CNTFNC78B15D612T'),
('7', '2025-05-10 18:00:00', 'LNGMIA99C03G224X', '90.00', '1005', 'NGLSRA92D50F839P'),
('8', '2025-05-31 10:20:00', 'RSSMGH00A01F556I', '110.00', '1006', 'MNTGPP88C30A662E'),
('9', '2025-05-31 10:50:00', 'VRDMRC90A01F556M', '100.00', '1006', 'MNTGPP88C30A662E'),
('10', '2025-06-01 15:45:00', 'VRDMRC90A01F556M', '75.00', '1007', 'SPSLGU90A01L219U');


INSERT INTO utilizzo (codice_trattamento, marca_prodotto, nome_prodotto) VALUES
('1', 'Bioline Jatò', 'Pure Gel Cleansing'),
('1', 'Avène', 'Cleanance Comedomed'),
('1', 'La Roche-Posay', 'Effaclar Duo'),
('1', 'CeraVe', 'Crema Viso Idratante'),
('2', 'CeraVe', 'Crema Viso Idratante'),
('3', 'Sothys Paris', 'Thermo-Active Salt Scrub'),
('4', 'Nuxe', 'Huile Prodigieuse'),
('5', 'Guam', 'Fango Termale Anticellulite'),
('5', 'Nuxe', 'Huile Prodigieuse'),
('6', 'Lancôme', 'Advanced Génifique Serum'),
('6', 'Avène', 'Cleanance Comedomed'),
('7', 'La Roche-Posay', 'Effaclar Duo'),
('7', 'Lancôme', 'Advanced Génifique Serum'),
('7', 'Bioline Jatò', 'Pure Gel Cleansing'),
('8', 'Lancôme', 'Advanced Génifique Serum'),
('9', 'Bioline Jatò', 'Pure Gel Cleansing'),
('9', 'Sothys Paris', 'Thermo-Active Salt Scrub'),
('10', 'Nuxe', 'Huile Prodigieuse');


--Restituire ogni trattamento che ha utilizzato un prodotto con scadenza entro 30 giorni dalla data del trattamento che utilizza tale prodotto.
DROP INDEX IF EXISTS idx_codice_trattamento;
DROP INDEX IF EXISTS idx_marca_nome;


CREATE INDEX idx_codice_trattamento ON utilizzo(codice_trattamento);
CREATE INDEX idx_marca_nome ON prodotto(marca, nome);


SELECT
    t.codice AS codice_trattamento,
    t.data_ora AS data_trattamento,
    u.marca_prodotto,
    u.nome_prodotto,
    p.data_scadenza AS scadenza_prodotto
FROM trattamento t
JOIN utilizzo u ON t.codice = u.codice_trattamento
JOIN prodotto p ON
        u.marca_prodotto = p.marca AND
        u.nome_prodotto = p.nome
WHERE p.data_scadenza BETWEEN t.data_ora::date AND (t.data_ora + INTERVAL '30 days')::date
ORDER BY t.data_ora, t.codice;


--Restituire i dipendenti specialisti che hanno eseguito trattamenti utilizzando almeno 3 prodotti diversi in un solo trattamento.
SELECT
    d.nome,
    d.cognome,
    t.codice AS codice_trattamento,
    t.data_ora AS data_trattamento,
    COUNT(*) AS numero_prodotti_usati
FROM dipendente d
JOIN specialista s ON d.cf = s.cf_spe
JOIN trattamento t ON s.cf_spe = t.cf_specialista
JOIN utilizzo u ON t.codice = u.codice_trattamento
GROUP BY d.nome, d.cognome, t.codice, t.data_ora
HAVING COUNT(*) >= 3
ORDER BY d.cognome, d.nome, t.data_ora;


--Trovare tutte le fatture il cui totale supera la media di tutte le fatture, e restituire nome e cognome degli specialisti che hanno eseguito i trattamenti riportati all’interno di queste fatture.
WITH trattamenti_distinti AS (
    SELECT DISTINCT codice, numero_fattura, prezzo, cf_specialista
    FROM trattamento
),
totali_fattura AS (
    SELECT numero_fattura, SUM(prezzo) AS totale_fattura
    FROM trattamenti_distinti
    GROUP BY numero_fattura
),
media_globale AS (
    SELECT AVG(totale_fattura) AS media
    FROM totali_fattura
),
fatture_sopra_media AS (
    SELECT t.numero_fattura, t.totale_fattura
    FROM totali_fattura t
    JOIN media_globale m ON t.totale_fattura > m.media
),
specialisti_fatture AS (
    SELECT DISTINCT f.numero_fattura, d.nome, d.cognome
    FROM trattamento tr
    JOIN fatture_sopra_media f ON tr.numero_fattura = f.numero_fattura
    JOIN specialista s ON tr.cf_specialista = s.cf_spe
    JOIN dipendente d ON s.cf_spe = d.cf
)
SELECT sf.numero_fattura, sf.nome, sf.cognome, m.media
FROM specialisti_fatture sf
JOIN media_globale m ON TRUE
ORDER BY sf.numero_fattura;


--Restituire codice fiscale, nome e cognome del cliente che ha speso di più in assoluto.
DROP VIEW IF EXISTS spesa_clienti;
DROP TABLE IF EXISTS spesa_clienti;

CREATE VIEW spesa_clienti AS
SELECT f.cf_cliente AS cf_cliente, SUM(t.prezzo) AS totale_speso
FROM fattura f
JOIN trattamento t ON f.numero = t.numero_fattura AND f.cf_cliente = t.cf_cliente
GROUP BY f.cf_cliente;

SELECT c.cf, c.nome, c.cognome,
    SUM(t.prezzo) AS totale_speso
FROM cliente c
JOIN trattamento t ON t.cf_cliente = c.cf
GROUP BY c.cf, c.nome, c.cognome
ORDER BY totale_speso DESC
LIMIT 1;


--Trovare tutti i trattamenti datati dal 2025 in poi dove è stato utilizzato il prodotto Bioline Jatò, Pure Gel Cleansing e restituire codice fiscale, nome, e cognome dei clienti che ne hanno usufruito.
SELECT c.cf AS cf_cliente, c.nome,c.cognome,
    t.codice AS codice_trattamento,
    t.data_ora,
    u.marca_prodotto,
    u.nome_prodotto
FROM trattamento t
JOIN utilizzo u ON t.codice = u.codice_trattamento
JOIN cliente c ON t.cf_cliente = c.cf
WHERE u.marca_prodotto = 'Bioline Jatò'
    AND u.nome_prodotto = 'Pure Gel Cleansing'
    AND t.data_ora > '2025-01-01 00:00:00'
ORDER BY t.data_ora;

--Restituire un elenco di tutti i dipendenti, mostrando per ciascuno il codice fiscale, il nome, il cognome. Inoltre, restituire la zona dell’area termale assegnata se è addetto, il titolo se è specialista e un’indicazione se è segretario; ordinarli per cognome.
CREATE INDEX IF NOT EXISTS idx_specialista_cf_spe ON specialista(cf_spe);
CREATE INDEX IF NOT EXISTS idx_addetto_cf_add ON addetto_at(cf_add);


SELECT DISTINCT
    d.cf,
    d.nome,
    d.cognome,
    ar.nome_zona AS area_lavoro,
    s.titolo AS titolo_specialista,
    CASE
        WHEN se.cf_seg IS NOT NULL THEN 'Sì'
        ELSE NULL
    END AS segretario
FROM dipendente d
LEFT JOIN addetto_at a ON d.cf = a.cf_add
LEFT JOIN area_termale ar ON a.zona = ar.id_zona
LEFT JOIN specialista s ON d.cf = s.cf_spe
LEFT JOIN segretario se ON d.cf = se.cf_seg
WHERE a.cf_add IS NOT NULL OR s.cf_spe IS NOT NULL OR se.cf_seg IS NOT NULL
ORDER BY d.cognome;


--Riportare i turni non assegnati agli addetti per ciascuna zona dell’area termale.
DROP VIEW IF EXISTS turni;
DROP TABLE IF EXISTS turni;

CREATE VIEW turni AS
SELECT 'Mattina' AS turno
UNION
SELECT 'Pomeriggio'
UNION
SELECT 'Sera';

SELECT a.id_zona, a.nome_zona, t.turno
FROM area_termale a, turni t
WHERE
    NOT EXISTS (
        SELECT *
                FROM addetto_at at
        WHERE at.zona = a.id_zona AND at.turno = t.turno
    )
ORDER BY a.id_zona, t.turno;
