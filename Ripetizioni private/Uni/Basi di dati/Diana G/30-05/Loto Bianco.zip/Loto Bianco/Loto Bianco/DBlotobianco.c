#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dependencies/include/libpq-fe.h"

#define DBNAME "LotoBianco"
#define USER "postgres"
#define PASSWORD "root"
#define HOST "127.0.0.1"
#define PORT "5432"

void getInputInt(const char *prompt, int *value) {
    int validInput = 0;
    while (!validInput) {
        printf("%s", prompt);
        validInput = scanf("%d", value);
        while (getchar() != '\n');
        if (!validInput) {
            printf("Input non valido: inserire un numero intero.\n");
        }
    }
}

void getInputFloat(const char *prompt, float *value) {
    int validInput = 0;
    while (!validInput) {
        printf("%s", prompt);
        validInput = scanf("%f", value);
        while (getchar() != '\n');
        if (!validInput) {
            printf("Input non valido: inserire un numero decimale.\n");
        }
    }
}

void printTable(PGresult *res) {
    int numColonne = PQnfields(res);
    int numRighe = PQntuples(res);

    if (numRighe == 0) {
        printf("Nessuna tupla trovata.\n");
        return;
    }

    // Calcolo della larghezza delle colonne
    int larghezzaColonne[numColonne];
    for (int i = 0; i < numColonne; i++) {
        larghezzaColonne[i] = strlen(PQfname(res, i));  // Lunghezza del nome della colonna
        for (int j = 0; j < numRighe; j++) {
            int dimensioneCampo = strlen(PQgetvalue(res, j, i));  // Lunghezza del valore del campo
            if (dimensioneCampo > larghezzaColonne[i]) {
                larghezzaColonne[i] = dimensioneCampo;
            }
        }
    }

    // Stampa dei nomi delle colonne
    for (int i = 0; i < numColonne; i++) {
        printf("%-*s ", larghezzaColonne[i] + 1, PQfname(res, i));
    }
    printf("\n");

    // Stampa di una linea di separazione
    for (int i = 0; i < numColonne; i++) {
        for (int j = 0; j < larghezzaColonne[i] + 1; j++) {
            printf("-");
        }
        printf("-");
    }
    printf("\n");

    // Stampa dei dati
    for (int i = 0; i < numRighe; i++) {
        for (int j = 0; j < numColonne; j++) {
            printf("%-*s ", larghezzaColonne[j] + 1, PQgetvalue(res, i, j));
        }
        printf("\n");
    }
}


void executeQuery(PGconn *conn, PGresult **res, const char *query) {
    *res = PQexec(conn, query);

    if (PQresultStatus(*res) != PGRES_TUPLES_OK) {
        fprintf(stderr, "Errore nella query: %s\n", PQerrorMessage(conn));
        PQclear(*res);
        *res = NULL;
        return;
    }

    printTable(*res);
}

void showMenu() {
    printf("\n");
    printf("Scegli un'opzione:\n");
    printf("1. Restituire ogni trattamento che ha utilizzato un prodotto con scadenza entro 30 giorni dalla data del trattamento che utilizza tale prodotto.\n");
    printf("2. Restituire i dipendenti specialisti che hanno eseguito trattamenti utilizzando almeno 3 prodotti diversi in un solo trattamento.\n");
    printf("3. Trovare tutte le fatture il cui totale supera la media di tutte le fatture, e restituire nome e cognome degli specialisti che hanno eseguito i trattamenti riportati all’interno di queste fatture.\n");
    printf("4. Restituire codice fiscale, nome e cognome del cliente che ha speso di più in assoluto.\n");
    printf("5. Trovare tutti i trattamenti datati dal 2025 in poi dove è stato utilizzato il prodotto Bioline Jatò, Pure Gel Cleansing e restituire codice fiscale, nome, e cognome dei clienti che ne hanno usufruito.\n");
    printf("6. Restituire un elenco di tutti i dipendenti, mostrando per ciascuno il codice fiscale, il nome, il cognome. Inoltre, restituire la zona dell’area termale assegnata se è addetto, il titolo se è specialista e un’indicazione se è segretario; ordinarli per cognome.\n");
    printf("7. Riportare i turni non assegnati agli addetti per ciascuna zona dell’area termale.\n");
    printf("0. Esci\n");
    printf("Scelta: ");
}

int main(int argc, char **argv) {

    char conninfo[250];
    snprintf(conninfo, sizeof(conninfo), "user=%s password=%s dbname=%s host=%s port=%s", USER, PASSWORD, DBNAME, HOST, PORT);
    PGconn *conn = PQconnectdb(conninfo);

    if (PQstatus(conn) == CONNECTION_BAD) {
        fprintf(stderr, "Connessione al database fallita: %s", PQerrorMessage(conn));
        exit(1);
    }

    const char* queries[7] = {
        // QUERY 1
         "SELECT \
                    t.codice AS codice_trattamento,\
                    t.data_ora AS data_trattamento, \
                    u.marca_prodotto,\
                    u.nome_prodotto,\
                    p.data_scadenza AS scadenza_prodotto\
                FROM trattamento t\
                JOIN utilizzo u ON t.codice = u.codice_trattamento\
                JOIN prodotto p ON \
                    u.marca_prodotto = p.marca AND \
                    u.nome_prodotto = p.nome\
                WHERE p.data_scadenza BETWEEN t.data_ora::date AND (t.data_ora + INTERVAL '30 days')::date\
                ORDER BY t.data_ora, t.codice;",

        // QUERY 2
         "SELECT \
                    d.nome,\
                    d.cognome, \
                    t.codice AS codice_trattamento, \
                    t.data_ora AS data_trattamento, \
                    COUNT(*) AS numero_prodotti_usati\
                FROM dipendente d\
                JOIN specialista s ON d.cf = s.cf_spe\
                JOIN trattamento t ON s.cf_spe = t.cf_specialista\
                JOIN utilizzo u ON t.codice = u.codice_trattamento\
                GROUP BY d.nome, d.cognome, t.codice, t.data_ora\
                HAVING COUNT(*) >= 3 \
                ORDER BY d.cognome, d.nome, t.data_ora;",

        // QUERY 3
         "WITH trattamenti_distinti AS (\
                    SELECT DISTINCT codice, numero_fattura, prezzo, cf_specialista\
                    FROM trattamento\
                ),\
                totali_fattura AS (\
                    SELECT numero_fattura, SUM(prezzo) AS totale_fattura\
                    FROM trattamenti_distinti\
                    GROUP BY numero_fattura\
                ),\
                media_globale AS (\
                    SELECT AVG(totale_fattura) AS media\
                    FROM totali_fattura\
                ),\
                fatture_sopra_media AS (\
                    SELECT t.numero_fattura, t.totale_fattura\
                    FROM totali_fattura t\
                    JOIN media_globale m ON t.totale_fattura > m.media\
                ),\
                specialisti_fatture AS (\
                    SELECT DISTINCT f.numero_fattura, d.nome, d.cognome\
                    FROM trattamento tr\
                    JOIN fatture_sopra_media f ON tr.numero_fattura = f.numero_fattura\
                    JOIN specialista s ON tr.cf_specialista = s.cf_spe\
                    JOIN dipendente d ON s.cf_spe = d.cf\
                )\
                SELECT sf.numero_fattura, sf.nome, sf.cognome, m.media\
                FROM specialisti_fatture sf\
                JOIN media_globale m ON TRUE\
                ORDER BY sf.numero_fattura;",

        // QUERY 4
         "CREATE VIEW spesa_clienti AS\
                SELECT f.cf_cliente AS cf_cliente, SUM(t.prezzo) AS totale_speso\
                FROM fattura f\
                JOIN trattamento t ON f.numero = t.numero_fattura AND f.cf_cliente = t.cf_cliente\
                GROUP BY f.cf_cliente;\
                \
                SELECT c.cf, c.nome, c.cognome,\
                    SUM(t.prezzo) AS totale_speso\
                FROM cliente c\
                JOIN trattamento t ON t.cf_cliente = c.cf\
                GROUP BY c.cf, c.nome, c.cognome\
                ORDER BY totale_speso DESC\
                LIMIT 1;",

        // QUERY 5
        "SELECT c.cf AS cf_cliente, c.nome,c.cognome,\
                t.codice AS codice_trattamento,\
                t.data_ora,\
                u.marca_prodotto,\
                u.nome_prodotto\
            FROM trattamento t\
            JOIN utilizzo u ON t.codice = u.codice_trattamento\
            JOIN cliente c ON t.cf_cliente = c.cf\
            WHERE u.marca_prodotto = 'Bioline Jat�'\
                AND u.nome_prodotto = 'Pure Gel Cleansing'\
                AND t.data_ora > '2025-01-01 00:00:00'\
            ORDER BY t.data_ora;",

        // QUERY 6
        "SELECT DISTINCT\
                    d.cf,\
                    d.nome,\
                    d.cognome,\
                    ar.nome_area AS area_lavoro,\
                    s.titolo AS titolo_specialista,\
                CASE \
                    WHEN se.cf_seg IS NOT NULL THEN 'S�'\
                    ELSE NULL\
                END AS segretario\
                FROM dipendente d\
                LEFT JOIN addetto_at a ON d.cf = a.cf_add\
                LEFT JOIN area_termale ar ON a.area = ar.id_area\
                LEFT JOIN specialista s ON d.cf = s.cf_spe\
                LEFT JOIN segretario se ON d.cf = se.cf_seg\
                WHERE a.cf_add IS NOT NULL OR s.cf_spe IS NOT NULL OR se.cf_seg IS NOT NULL\
                ORDER BY d.cognome;",

        // QUERY 7
        "CREATE VIEW turni AS\
                SELECT 'Mattina' AS turno\
                UNION\
                SELECT 'Pomeriggio'\
                UNION\
                SELECT 'Sera';\
                \
                SELECT a.id_area, a.nome_area, t.turno\
                FROM area_termale a, turni t\
                WHERE \
                    NOT EXISTS (\
                        SELECT *\
                        FROM addetto_at at\
                        WHERE at.area = a.id_area AND at.turno = t.turno\
                    )\
                ORDER BY a.id_area, t.turno;"
    };

    int scelta;
    PGresult *res = NULL;

    while (1) {
        showMenu();
        getInputInt("Inserisci la tua scelta: ", &scelta);
        printf("\n");

        switch (scelta) {
            case 1: {
                int giorni_scadenza;
                printf("Inserisci il numero di giorni dalla data del trattamento entro cui considerare i prodotti in scadenza: ");
                scanf("%d", &giorni_scadenza);

                // Validazione input
                while (giorni_scadenza < 0) {
                    printf("Il numero di giorni deve essere positivo: ");
                    scanf("%d", &giorni_scadenza);
                }

                printf("\n");
                printf("QUERY 1: Trattamenti che hanno utilizzato prodotti con scadenza entro %d giorni dalla data del trattamento\n\n", giorni_scadenza);

                char query1[1000];
                    snprintf(query1, sizeof(query1),
                        "SELECT \
                            t.codice AS codice_trattamento,\
                            t.data_ora AS data_trattamento, \
                            u.marca_prodotto,\
                            u.nome_prodotto,\
                            p.data_scadenza AS scadenza_prodotto\
                        FROM trattamento t\
                        JOIN utilizzo u ON t.codice = u.codice_trattamento\
                        JOIN prodotto p ON \
                            u.marca_prodotto = p.marca AND \
                            u.nome_prodotto = p.nome\
                        WHERE p.data_scadenza BETWEEN t.data_ora::date AND (t.data_ora + INTERVAL '%d days')::date\
                        ORDER BY t.data_ora, t.codice;",
                        giorni_scadenza);

                executeQuery(conn, &res, query1);
                break;
            }

            case 2: {
                int num_prodotti;
                printf("Inserisci il numero minimo di prodotti utilizzati in un singolo trattamento: ");
                scanf("%d", &num_prodotti);

                // Validazione input
                while (num_prodotti < 1) {
                    printf("Il numero di prodotti deve essere almeno 1, riprova: ");
                    scanf("%d", &num_prodotti);
                }

                printf("\n");
                printf("Query 2: Dipendenti specialisti che hanno eseguito trattamenti utilizzando almeno %d prodotti in una sola volta\n\n", num_prodotti);

                char query2[1000];
                snprintf(query2, sizeof(query2),
                    "SELECT \
                        d.nome, \
                        d.cognome, \
                        t.codice AS codice_trattamento,\
                        t.data_ora AS data_trattamento,\
                        COUNT(*) AS numero_prodotti_usati\
                    FROM dipendente d\
                    JOIN specialista s ON d.cf = s.cf_spe\
                    JOIN trattamento t ON s.cf_spe = t.cf_specialista\
                    JOIN utilizzo u ON t.codice = u.codice_trattamento\
                    GROUP BY d.nome, d.cognome, t.codice, t.data_ora\
                    HAVING COUNT(*) >= %d\
                    ORDER BY d.cognome, d.nome, t.data_ora;",
                    num_prodotti);

                executeQuery(conn, &res, query2);
                break;
            }

            case 3: {
                float soglia_fattura;
                printf("Inserisci l'importo minimo per le fatture (invece della media): ");
                scanf("%f", &soglia_fattura);

                // Validazione input
                while (soglia_fattura < 0) {
                    printf("L'importo deve essere positivo, riprova: ");
                    scanf("%f", &soglia_fattura);
                }

                printf("\n");
                printf("Query 3: Fatture con totale superiore a %.2f euro e relativi specialisti\n\n", soglia_fattura);

                char query3[1500];
                snprintf(query3, sizeof(query3),
                    "WITH trattamenti_distinti AS (\
                        SELECT DISTINCT codice, numero_fattura, prezzo, cf_specialista\
                        FROM trattamento\
                    ),\
                    totali_fattura AS (\
                        SELECT numero_fattura, SUM(prezzo) AS totale_fattura\
                        FROM trattamenti_distinti\
                        GROUP BY numero_fattura\
                    ),\
                    fatture_sopra_soglia AS (\
                        SELECT numero_fattura, totale_fattura\
                        FROM totali_fattura\
                        WHERE totale_fattura > %.2f\
                    ),\
                    specialisti_fatture AS (\
                        SELECT DISTINCT f.numero_fattura, f.totale_fattura, d.nome, d.cognome\
                        FROM trattamento tr\
                        JOIN fatture_sopra_soglia f ON tr.numero_fattura = f.numero_fattura\
                        JOIN specialista s ON tr.cf_specialista = s.cf_spe\
                        JOIN dipendente d ON s.cf_spe = d.cf\
                    )\
                    SELECT numero_fattura, totale_fattura, nome, cognome, %.2f AS soglia_utilizzata\
                    FROM specialisti_fatture\
                    ORDER BY totale_fattura DESC, numero_fattura;",
                    soglia_fattura, soglia_fattura);

                executeQuery(conn, &res, query3);
                break;
            }

            case 4: {
                int numero_clienti;
                printf("Inserisci quanti clienti top spender vuoi visualizzare: ");
                scanf("%d", &numero_clienti);

                while (numero_clienti < 1) {
                    printf("Il numero deve essere almeno 1, riprova: ");
                    scanf("%d", &numero_clienti);
                }

                printf("\n");
                printf("Query 4: Top %d clienti che hanno speso di pi�\n\n", numero_clienti);

                char query4[800];
                snprintf(query4, sizeof(query4),
                    "SELECT c.cf, c.nome, c.cognome, \
                        SUM(t.prezzo) AS totale_speso\
                    FROM cliente c\
                    JOIN trattamento t ON t.cf_cliente = c.cf\
                    GROUP BY c.cf, c.nome, c.cognome\
                    ORDER BY totale_speso DESC\
                    LIMIT %d;",
                    numero_clienti);

                executeQuery(conn, &res, query4);
                break;
            }

            case 5: {
                char data_inizio[20];
                char marca[100], prodotto[100];

                printf("Inserisci la data di inizio (formato YYYY-MM-DD, es. 2025-01-01): ");
                scanf("%19s", data_inizio);

                printf("Inserisci la marca del prodotto: ");
                scanf(" %99[^\n]", marca);  // Legge anche spazi

                printf("Inserisci il nome del prodotto: ");
                scanf(" %99[^\n]", prodotto);  // Legge anche spazi

                printf("\n");
                printf("Query 5: Trattamenti dal %s in poi con prodotto '%s - %s'\n\n", data_inizio, marca, prodotto);

                char query5[1200];
                snprintf(query5, sizeof(query5),
                    "SELECT c.cf AS cf_cliente, c.nome, c.cognome,\
                        t.codice AS codice_trattamento,\
                        t.data_ora,\
                        u.marca_prodotto,\
                        u.nome_prodotto\
                    FROM trattamento t\
                    JOIN utilizzo u ON t.codice = u.codice_trattamento\
                    JOIN cliente c ON t.cf_cliente = c.cf\
                    WHERE u.marca_prodotto = '%s'\
                        AND u.nome_prodotto = '%s'\
                        AND t.data_ora >= '%s 00:00:00'\
                    ORDER BY t.data_ora;",
                    marca, prodotto, data_inizio);

                executeQuery(conn, &res, query5);
                break;
            }

            case 6: {
                int tipo_dipendente;
                printf("Scegli il tipo di dipendente da visualizzare:\n");
                printf("1. Solo addetti alle aree termali\n");
                printf("2. Solo specialisti\n");
                printf("3. Solo segretari\n");
                printf("4. Tutti i dipendenti\n");
                printf("Scelta: ");
                scanf("%d", &tipo_dipendente);

                while (tipo_dipendente < 1 || tipo_dipendente > 4) {
                    printf("Scelta non valida, riprova (1-4): ");
                    scanf("%d", &tipo_dipendente);
                }

                char query6[1200];
                char where_condition[300] = "";

                switch(tipo_dipendente) {
                    case 1:
                        strcpy(where_condition, "WHERE a.cf_add IS NOT NULL");
                        break;
                    case 2:
                        strcpy(where_condition, "WHERE s.cf_spe IS NOT NULL");
                        break;
                    case 3:
                        strcpy(where_condition, "WHERE se.cf_seg IS NOT NULL");
                        break;
                    case 4:
                        strcpy(where_condition, "WHERE a.cf_add IS NOT NULL OR s.cf_spe IS NOT NULL OR se.cf_seg IS NOT NULL");
                        break;
                }

                snprintf(query6, sizeof(query6),
                    "SELECT DISTINCT\
                        d.cf,\
                        d.nome,\
                        d.cognome,\
                        ar.nome_zona AS area_lavoro,\
                        s.titolo AS titolo_specialista,\
                        CASE \
                            WHEN se.cf_seg IS NOT NULL THEN 'S�'\
                            ELSE NULL\
                        END AS segretario\
                    FROM dipendente d\
                    LEFT JOIN addetto_at a ON d.cf = a.cf_add\
                    LEFT JOIN area_termale ar ON a.zona = ar.id_zona\
                    LEFT JOIN specialista s ON d.cf = s.cf_spe\
                    LEFT JOIN segretario se ON d.cf = se.cf_seg\
                    %s\
                    ORDER BY d.cognome;",
                    where_condition);

                executeQuery(conn, &res, query6);
                break;
            }

            case 7: {
                char turno_scelto[15];
                int scelta_turno;

                printf("Scegli il turno da verificare:\n");
                printf("1. Mattina\n");
                printf("2. Pomeriggio\n");
                printf("3. Sera\n");
                printf("4. Tutti i turni\n");
                printf("Scelta: ");
                scanf("%d", &scelta_turno);

                while (scelta_turno < 1 || scelta_turno > 4) {
                    printf("Scelta non valida, riprova (1-4): ");
                    scanf("%d", &scelta_turno);
                }

                // Determina il turno in base alla scelta
                switch(scelta_turno) {
                    case 1:
                        strcpy(turno_scelto, "Mattina");
                        break;
                    case 2:
                        strcpy(turno_scelto, "Pomeriggio");
                        break;
                    case 3:
                        strcpy(turno_scelto, "Sera");
                        break;
                    case 4:
                        strcpy(turno_scelto, "TUTTI");
                        break;
                }

                printf("\n");
                if (scelta_turno == 4) {
                    printf("Query 7: Tutte le aree con turni non assegnati\n\n");
                } else {
                    printf("Query 7: Aree con turno '%s' non assegnato\n\n", turno_scelto);
                }

                char query7[1000];

                if (scelta_turno == 4) {
                    // Mostra tutti i turni non assegnati
                    snprintf(query7, sizeof(query7),
                        "CREATE VIEW turni AS\
                        SELECT 'Mattina' AS turno\
                        UNION\
                        SELECT 'Pomeriggio'\
                        UNION\
                        SELECT 'Sera';\
                        \
                        SELECT a.id_zona, a.nome_zona, t.turno\
                        FROM area_termale a, turni t\
                        WHERE \
                            NOT EXISTS (\
                                SELECT *\
                                FROM addetto_at at\
                                WHERE at.zona = a.id_zona AND at.turno = t.turno\
                            )\
                        ORDER BY a.id_zona, t.turno;");
                } else {
                    // Mostra solo il turno specifico non assegnato
                    snprintf(query7, sizeof(query7),
                        "SELECT a.id_zona, a.nome_zona, '%s' AS turno\
                        FROM area_termale a\
                        WHERE \
                            NOT EXISTS (\
                                SELECT *\
                                FROM addetto_at at\
                                WHERE at.zona = a.id_zona AND at.turno = '%s'\
                            )\
                        ORDER BY a.id_zona;",
                        turno_scelto, turno_scelto);
                }

                executeQuery(conn, &res, query7);
                break;
            }

            case 0:
                printf("Uscita dal programma.\n");
                PQfinish(conn);
                return 0;
            default:
                printf("Scelta non valida. Riprova.\n");
                break;
            }

        PQclear(res);
        res = NULL;
    }

    PQfinish(conn);
    return 0;
}
