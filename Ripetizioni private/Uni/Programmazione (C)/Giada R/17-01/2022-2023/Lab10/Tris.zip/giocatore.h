#ifndef GIOCATORE_H
#define GIOCATORE_H

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "board.h"


/* 
 * 	Chiede la mossa all'utente
 */
void scegli_mossa_utente(char board[], int *x, int *y);
/* PRE: x e y sono due variabili intere passate per riferimento.
 * POST: x,y contengono le coordinate della prossima mossa fornita dall'utente da tastiera, dove (0,0) 
 * indica la casella più in alto a sinistra e 0<=*x<BOARD_LATO, 0<=*y<BOARD_LATO. board non viene utilizzata.
 */

/* 
 * 	Seleziona la mossa del computer come avversario in modo random
 */
void scegli_mossa_computer(char board[], int *x, int *y);
/* PRE: x e y sono due variabili intere passate per riferimento.
 * POST: x,y contengono le coordinate della prossima mossa scelta casualmente dal computer (usando rand()), dove (0,0) indica la casella più 
 * in alto a sinistra e 0<=*x<BOARD_LATO, 0<=*y<BOARD_LATO. board non viene utilizzata.
 */
/* Notate che potete usare la costante BOARD_LATO nel vostro codice. */

/*
 * Versione migliorata di scegli_mossa_computer. Utilizza una strategia intelligente per vincere.
 */
void scegli_mossa_computer_migliore(char board[], int *x, int *y);
/* PRE: x e y sono due variabili intere passate per riferimento.
 * POST: Il computer sceglie la mossa che minimizza il numero di configurazioni perdenti a cui può potenzialmente condurre.
 * Esempio:
 * Situazione iniziale (siamo "x" ed è il nostro turno)
 *   | o | 
 * ----------
 * o |   | x 
 * ----------
 * o |   | x
 * Caso 1 (x in alto a sinistra): due possibili sconfitte (le parentesi segnano quale "o" viene giocato prima dall'avversario) 
 * x | o | o      x | o |[o]
 * ----------    -----------
 * o |[o]| x      o | o | x
 * ----------    -----------
 * o | x | x      o | x | x
 * Caso 2 (x al centro o in basso): mostriamo le configurazioni per il centro, due possibili sconfitte
 * o | o |        o | o |[o]
 * ----------    -----------
 * o | x | x      o | x | x  
 * ----------    -----------
 * o |   | x      o | x | x 
 * Caso 3 (x in alto a destra): abbiamo vinto, zero possibili sconfitte
 *   | o | x
 * ----------
 * o |   | x 
 * ----------
 * o |   | x
 * x,y contengono le coordinate della prossima mossa scelta dal computer, dove (0,0) indica la casella più 
 * in alto a sinistra e 0<=*x<BOARD_LATO, 0<=*y<BOARD_LATO. board non viene utilizzata.
 */


void scegli_mossa_computer_prob_max(char board[], int *x, int *y);
    /*
        PRE: 0<=*x<BOARD_LATO, 0<=*y<BOARD_LATO 
        POST: al termine (*x,*y) indica la mossa con più alta probabilità di vittoria per SIMB_O (calcolatore)
    */

#endif
