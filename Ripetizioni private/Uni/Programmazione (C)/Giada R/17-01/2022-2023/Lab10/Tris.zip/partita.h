#ifndef PARTITA_H
#define PARTITA_H


#include <stdio.h>
#include <string.h>
#include "board.h"
#include "giocatore.h"

/*
    Gioca una partita di tris. I parametri della funzione sono la board, e due puntatori a funzioni che indicano come la prossima mossa debba essere scelta, sono disponibili in giocatore.h.
 */
void gioca(char board[], void(*p1)(char [], int *, int *), void(*p2)(char [], int *, int *));

/*
 * PRE: board ha dimensione BOARD_SIZE
 * POST: Una partita completa di tris è stata giocata (vedere dettagli sotto)
 */
/*
    Struttura di gioca()
    1) leggetevi le funzioni a disposizione in board.h ed utilizzatele!
    2) La funzione gioca ha la seguente struttura: finché la partita non è finita (ovvero finché uno dei due giocatori ha vinto o non sono possibili ulteriori mosse perché la board è statà riempita) si fa effettuare una mossa ad uno dei due giocatori (bisogna mantenere l'informazione su chi debba scegliere la mossa ad ogni turno): 
        2.1) la mossa viene selezionata utilizzando le funzioni indicate dai puntatori p1 e p2; si deve poi controllare che la mossa sia valida (altrimenti ne deve essere richiesta un'altra)
        2.2) si effettua la mossa modificando la board e stampandola
    Una volta usciti dal ciclo sopra, si controlla se è perché uno dei due giocatori ha vinto (si stampa un messaggio di vittoria) o se non sono possibili altre mosse (si stampa che la partita è finita in parità).
*/


/* 
   Il file di salvataggio su cui lavoreremo sarà di tipo binario e chiamato "salvataggio_partita.dat", ed è organizzato nella seguente maniera:
	1- modalità
	2- turno corrente
	3- tutti i simboli delle posizioni nella board 
   
	Attenzione: alcuni simboli hanno una rappresentazione specofica, potete osservare le variabili utilizzate nel main.
*/

/*
    Salva partita su file
*/
void salva_partita(char modalita[], char board[], int turno);
/*
 * PRE board ha dimensione BOARD_SIZE, modalita ha dimensione sufficiente a contenere i nomi delle modalità, turno può essere 0/1
 * POST Le variabili vengono salvate in un file di cache
 */

/*
    Carica una partita da file
*/
void carica_partita(char modalita[], char board[], int* turno);
/*
 * PRE board ha dimensione BOARD_SIZE, modalita ha dimensione sufficiente a contenere i nomi delle modalità, turno può essere 0/1
 * POST Le variabili vengono inizializzate con la partita salvata nel file
 */
 

/*
    Dopo aver eseguito una mossa, aggiorna il cambiamento di una posizione della board su file
*/
void aggiorna_partita(int x, int y, char simbolo, int turno);
/*
 * PRE x e y sono coordinate di una posizione nella board, simbolo contiene il segno della mossa appena fatta
 * POST è stata aggiornata la posizione (x,y) nella board salvata su file con il carattere simbolo, turno è il turno corrente
 */


#endif
