#include <stdio.h>

/*
    Funzione che riduce una frazione ai minimi termini
*/


int main() {
          
    int num, den;
    scanf("%d", &num);
    scanf("%d", &den);
    printf("%d/%d=", num, den);

    // INVOCARE QUA MINIMI_TERMINI()
    
    //

    printf("%d/%d\n", num, den);

}
