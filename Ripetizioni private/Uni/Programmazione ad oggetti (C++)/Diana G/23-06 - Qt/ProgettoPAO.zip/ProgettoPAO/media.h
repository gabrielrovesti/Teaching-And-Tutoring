#ifndef MEDIA_H
#define MEDIA_H

#include <QString>

class Media {

    protected:
        QString titolo;

    public:
        Media(const QString& titolo);
        virtual ~Media() = default;

        QString getTitolo() const;
        virtual QString getTipo() const = 0;
        virtual QString descrizione() const = 0;


};

#endif // MEDIA_H
