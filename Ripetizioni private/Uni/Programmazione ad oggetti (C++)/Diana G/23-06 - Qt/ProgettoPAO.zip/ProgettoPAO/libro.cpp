#include "libro.h"

Libro::Libro(const QString& titolo, const QString& autore, int anno)
    : Media(titolo), autore(autore), anno(anno) {}

QString Libro::getTipo() const {
    return "Libro";
}

QString Libro::descrizione() const {
    return getTitolo() + " di " + autore + " (" + QString::number(anno) + ")";
}
