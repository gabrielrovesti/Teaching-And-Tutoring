#include "media.h"

Media::Media(const QString& titolo) : titolo(titolo) {}

QString Media::getTitolo() const {
    return titolo;
}
