#ifndef LIBRO_H
#define LIBRO_H

#include "media.h"
#include <QString>

class Libro : public Media {
    public:
        Libro(const QString& titolo, const QString& autore, int anno);

        QString getTipo() const override;
        QString descrizione() const override;

    private:
        QString autore;
        int anno;
};
#endif // LIBRO_H
