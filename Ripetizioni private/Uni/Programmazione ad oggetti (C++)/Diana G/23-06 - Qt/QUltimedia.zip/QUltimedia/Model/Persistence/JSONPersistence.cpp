#include "JSONPersistence.h"

JSONPersistence::JSONPersistence() {}
