#ifndef BOOK_H
#define BOOK_H

class Book
{
public:
    Book();
};

#endif // BOOK_H
