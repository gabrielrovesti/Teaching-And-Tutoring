#ifndef COMIC_H
#define COMIC_H

class Comic
{
public:
    Comic();
};

#endif // COMIC_H
