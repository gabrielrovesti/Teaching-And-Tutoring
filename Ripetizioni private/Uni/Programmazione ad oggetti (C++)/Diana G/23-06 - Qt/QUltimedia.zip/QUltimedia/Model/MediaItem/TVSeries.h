#ifndef TVSERIES_H
#define TVSERIES_H

class TVSeries
{
public:
    TVSeries();
};

#endif // TVSERIES_H
