#include "Comic.h"

Comic::Comic() {}
