#ifndef MAGAZINE_H
#define MAGAZINE_H

class Magazine
{
public:
    Magazine();
};

#endif // MAGAZINE_H
