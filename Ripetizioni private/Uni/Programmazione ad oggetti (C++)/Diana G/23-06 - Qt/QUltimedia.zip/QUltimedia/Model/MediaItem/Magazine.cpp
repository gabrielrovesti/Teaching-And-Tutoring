#include "Magazine.h"

Magazine::Magazine() {}
