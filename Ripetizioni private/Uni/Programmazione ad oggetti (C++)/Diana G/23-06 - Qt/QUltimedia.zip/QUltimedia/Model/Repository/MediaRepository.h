#ifndef MEDIAREPOSITORY_H
#define MEDIAREPOSITORY_H

class MediaRepository
{
public:
    MediaRepository();
};

#endif // MEDIAREPOSITORY_H
