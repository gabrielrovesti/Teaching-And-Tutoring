#include "Book.h"

Book::Book() {}
