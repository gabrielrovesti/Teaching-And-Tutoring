#ifndef MEDIAITEM_H
#define MEDIAITEM_H

class MediaItem
{
public:
    MediaItem();
};

#endif // MEDIAITEM_H
