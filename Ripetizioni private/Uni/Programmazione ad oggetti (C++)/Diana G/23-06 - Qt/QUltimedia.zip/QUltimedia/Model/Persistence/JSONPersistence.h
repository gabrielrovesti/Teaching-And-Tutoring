#ifndef JSONPERSISTENCE_H
#define JSONPERSISTENCE_H

class JSONPersistence
{
public:
    JSONPersistence();
};

#endif // JSONPERSISTENCE_H
