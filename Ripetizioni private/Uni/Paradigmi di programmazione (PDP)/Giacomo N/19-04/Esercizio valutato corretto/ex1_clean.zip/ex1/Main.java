package it.unipd.pdp2023.ex1;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

/** Main class */
public class Main {

  public static void main(String[] args) throws InterruptedException {

    AtomicInteger eidx = new AtomicInteger(0);
    List<Element> program =
        Stream.of(
                "4S",
                "4T",
                "3F",
                "FCCoSp4",
                "StSq3",
                "4S+3T",
                "4T+REP",
                "3A+1Lo+3S",
                "3Lo",
                "3Lz",
                "FCSSp4",
                "ChSq1",
                "CCoSp4")
            .map(s -> new Element(eidx.incrementAndGet(), s))
            .toList();

    // set up the rink
    var rink = null; // TODO

    // set up the athlete
    Athlete hanyuYusuru = new Athlete(rink, program);

    // set up the rink video system and vote collection
    VideoSystem video = new VideoSystem(rink);
    var votes = null; // TODO

    // set up the judges and technical panel
    AtomicInteger jidx = new AtomicInteger(0);
    var judges =
        List.of(Nation.values()).stream()
            .map(n -> new Judge(n, jidx.incrementAndGet(), video.screen(), votes))
            .toList();
    var techPanel = new TechnicalPanel(video.screen(), votes);

    // set up the score board
    var score = new ScoreBoard(votes);

    // set up the 1s printer
    var printer = new Printer(score);

    // start the athlete, the judges, the technical panel and the scoring board

    // TODO: start what needs to be started

    // check if exercise and scoring is over
    do {
      Thread.sleep(5000);
    } while (false /* TODO */); // check if relevant components have stopped);

    // TODO: stop components that don't stop themselves
  }
}
